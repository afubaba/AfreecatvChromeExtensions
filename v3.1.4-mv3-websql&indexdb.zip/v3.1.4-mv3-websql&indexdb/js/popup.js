// document.addEventListener('DOMContentLoaded', function() {
//     var checkPageButton = document.getElementById('clickIt');
//     checkPageButton.addEventListener('click', function() {
  
//       chrome.tabs.getSelected(null, function(tab) {
//         alert("Hello..! It's my first chrome extension.");

//          chrome.tabs.sendRequest(tab.id, { action:  "GetBaiduKeyWord"  },  function  (response) {
//              alert(response.kw);
//          });
//       });
//     }, false);
//   }, false);

//设置时间
setDomTimeById("timeFrequencys");
// const rnName = chrome.i18n.getMessage(name);
// var errorDetails1="3."
// var errorDetails2="1.3"
// console.log(chrome.i18n.getMessage("error", [errorDetails1,errorDetails2]));
// console.log(chrome.i18n.getMessage("version", [errorDetails1,errorDetails2]));