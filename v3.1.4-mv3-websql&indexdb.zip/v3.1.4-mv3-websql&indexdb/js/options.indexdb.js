var req;
var opIndexDB = {
	aa: function() {
		console.log("test");
	},
	getDB: function(dbName, version) {
		req = indexedDB.open(dbName, version);
		return req;
	},
	createTable: function(dbName, version, tbName) {
		req = this.getDB(dbName, version);
		req.onupgradeneeded = function(e) {
			console.error('onupgradeneeded');
			var db = req.result;
			// var store = db.createObjectStore("student", {autoIncrement: true}); 使用自增键
			// 创建student表
			var store = db.createObjectStore(tbName, {
				keyPath: 'id'
			});
			// 设置id为主键
			store.createIndex(tbName + '_id_unqiue', 'id', {
				unique: true
			});
		}
		return req;
	},
	insertData: function(dbName, version, tbName, options) {
		req = this.createTable(dbName, version, tbName);
		req.onsuccess = function(event) {
			console.log('onsuccess');
			// 获取数据库
			var db = event.target.result;
			// var transaction = db.transaction('option', 'readwrite');
			console.log(tbName);
			var transaction = db.transaction([tbName], 'readwrite');
			transaction.onsuccess = function(event) {
				console.log('[Transaction] 好了!');
			};
			transaction.onerror = function(event) {
				console.log('[Transaction] 失败!');
			};
			//读取表名
			var optionsStore = transaction.objectStore(tbName);
			options.forEach(function(option) {
				//数据储存
				console.log(option);
				var db_op_req = optionsStore.add(option);
				db_op_req.onsuccess = function() {
					console.log("存好了");
				}
			});
		}
		req.onerror = function() {
			console.log("数据库出错");
		}
	},
	searchById: function(id, dbName, version, tbName) {
		req = this.createTable(dbName, version, tbName);
		req.onsuccess = function(events) {
			// 获取数据库
			var db = events.target.result;
			// var transaction = db.transaction('student', 'readwrite');
			var transaction = db.transaction([tbName], 'readwrite');
			transaction.onsuccess = function(event) {
				console.log('[Transaction] 好了!');
			};
			transaction.onerror = function(event) {
				console.log('[Transaction] 失败!');
			};

			//读取表名
			var optionsStore = transaction.objectStore(tbName);
			optionsStore.get(id).onsuccess = function(event) {
				// console.log("id为" + id + "的配置是", event.target.result);
				// seData(event.target.result);
				var data = event.target.result;
				
				getDomById("background_color").value = data.fontColor;
				getDomById("background").value = data.backColor;
				

				// return event.target.result;
			};
		}
		req.onerror = function(events) {
			console.log("searchById查询出错了");
		}
	},
	updateData: function(option, dbName, version, tbName) {
		req = this.createTable(dbName, version, tbName);
		req.onsuccess = function(events) {

			// 获取数据库
			var db = events.target.result;
			// var transaction = db.transaction('student', 'readwrite');
			var transaction = db.transaction([tbName], 'readwrite');
			transaction.onsuccess = function(event) {
				console.log('[Transaction] 好了!');
			};
			transaction.onerror = function(event) {
				console.log('[Transaction] 失败!');
			};

			//读取表名
			var optionsStore = transaction.objectStore(tbName);
			console.log(optionsStore);
			optionsStore.put(option).onsuccess = function(event) {
				console.log('更新id为1的学生姓名', event.target.result);
			};
		}
		req.onerror = function(events) {
			console.log("updateData更新出错了");
		}
	}
}

