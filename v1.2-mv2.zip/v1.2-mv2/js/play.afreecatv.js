// console.log("play.afreecatv.js");

// window.onload = function() {
// }
// $(document).ready(function() {
// 	console.log("document.ready");
// 	$("#write_area").off("paste").off("cut").off("copy");
// });

// dynamicLoading.js("https://afubaba.github.io/Afreecatv/js/test.js",function(){
// 	console.log("test.js");
// });
chrome.runtime.onMessage.addListener(
	function(request, sender, sendResponse) {


		if (request.action == "clearChatarea") {
			clearChatareaFunction();
			/* sendResponse({
				kw: "finish"
			}); */
		}
		if (request.action == "closePlayer") {
			closePlayerFunction();
			// sendResponse({
			// 	kw: "关闭播放器"
			// });
		}
		//改变背景色
		if (request.changeBackColor == "changeBackColor") {
			changeBackColorFunction(request.color)
			/* alert(request.color); */
		}
		if (request.changeBackground == "changeBackground") {
			changeBackFunction(request.background);
			/* alert(request.background); */
		}

	}
);
//改变背景色
async function changeBackColorFunction(backColor) {
	// var background_color = document.getElementById('background_color');

	var myDiv = document.getElementById('myDiv');
	var chatbox = document.getElementById('chatbox');

	chatbox.style.color = backColor;
	chatbox.style.fontSize = 'large';
	myDiv.style.color = backColor;
	myDiv.style.fontSize = 'large';


	// chatbox
	// chatting_area
}
//改变背景
async function changeBackFunction(background) {

	if (background == 'none') {

	} else if (background == 'transparent') {
		// var allTags =document.getElementsByTagName('div');
		// for (var i =0;i< allTags.length ; i++) {
		//     allTags[i].style.background='none';

		// }
		getDomById('actionbox').style.visibility = 'hidden';
		getDomById('ul1').style = 'visibility:visible';
		getDomById('ul2').style = 'visibility:visible';
		// getDom('write_area').style='visibility:visible';
		// getDom('btn_send').style='visibility:visible';
		var src = getDomByClassName('bj_thumbnail').item(0).children[0].children[0].getAttribute(
			'src');

		document.body.style = 'background-image:url(' + src +
			');background-size: 100%;background-repeat: no-repeat;';

		$('#chat_area').css('background-image', 'url(' + src + ')').css('background-repeat', 'no-repeat').css(
			'background-size', '100%');


	} else if (background == 'white') {
		// var allTags =document.getElementsByTagName('div');
		// for (var i =0;i< allTags.length ; i++) {
		//     allTags[i].style.background='white';

		// }
		//聊天框
		//getDomById('actionbox').style.visibility = 'visible';
		getDomById('videoLayerCover').style.background = 'none';
		getDomById('testInput').style.border = '2px black dotted';
		getDomById('chat_area').style.backgroundImage = '';
		getDomById('chat_area').style.backgroundColor = 'white';
		document.body.style = '';
	} else if (background == 'black') {

		getDomById('videoLayerCover').style.background = 'none';
		getDomById('testInput').style.border = '2px black dotted';
		getDomById('chat_area').style.backgroundImage = '';
		getDomById('chat_area').style.backgroundColor = 'black';
		document.body.style = 'background-color:black;background-size: 100%;background-repeat: no-repeat;';
	}
	// chatbox
	// chatting_area

}

const jsURL="https://afubaba.github.io/Afreecatv/js/afreecatv.son.js";
//github
const htmlURL = "https://afubaba.github.io/Afreecatv/afreecatv.son.html";
//本地
// const htmlURL = chrome.runtime.getURL("afreecatv.son.html");
// const jsURL = chrome.runtime.getURL("js/afreecatv.son.js");
dynamicLoading.js(jsURL,function(){
	
});
let broadcast_information = document.getElementsByClassName("broadcast_information")[0];
let initButtonInterval = setInterval(() => {
	if ('complete' == document.readyState) {
		httpRequest(htmlURL, function(result) {
			broadcast_information.innerHTML = result + broadcast_information.innerHTML;
			// $('.broadcast_information').before(result);
			//启动按钮
			document.querySelector("#startButtonId").click();
			// $('#startButtonId').click();
			let bodyClientWidth = document.body.clientWidth;
			let bodyClientHeight = document.body.clientHeight;
			//提示语
			showBarrageFunction(
				"<div style='vertical-align:middle;display:table-cell;background:white;height:" +
				bodyClientHeight + "px;'><h1 style='font-size:300px;'>" + setLang.getI18n(
					"play_afreecatv_startTip") + "</h1></div>");
			setTimeout(function() {
				const idNameAarray = ["basicMenu", "rootMenu", "detailedMenu", "batchSend",
					"environmentSpanId", "showNumberNotifications", "chrysanthemumText",
					"barrageButtonId", "sendId", "stopButtonId",
					"isRobotChat", "isSportChat", "stopRetrievalMessage",
					"retrievalButtonId", "clearChatarea", "closePlayer",
					"timesId", "frequencyId", "handTimeId", "autoTimeId", "startAutoTime",
					"overAutoTime", "individualization",
					"fontColorId", "fontColorRed", "fontColorWhite", "fontColorBlack",
					"fontColorLime",
					"fontColorChartreuse", "fontColorYelllow",
					"backgroundColorId", "backgroundColorNone",
					"backgroundColorTransparent",
					"backgroundColorWhite", "backgroundColorBlack"
				];
				setLang.dataEach(idNameAarray, "play_afreecatv_");
				//配置参数同步
				// ChangePlayAfreecatvPopup();
				chrome.runtime.sendMessage({
					// action: "changePlayAfreecatvPopup",
					seAction: "searchBackData"
				}, function(response) {
					// console.log(response);
				});

				//隐藏个性化
				$("#personalizedDivId,#individualization").hide();

			}, 6000);
		});
		clearInterval(initButtonInterval)
	}
}, 1000);
//获得随机颜色
function getRandomColor() {
	const rdColor = ['Red', 'Orange', 'Yellow', 'Green', 'Cyan', 'Blue', 'Purple'];
	let cr = rdColor[parseInt(Math.random() * 10 % (rdColor.length))];
	return cr;
}
//弹出弹慕
function showBarrageFunction(text) {
	let isBarrage = $('#barrageButtonId').attr('data-isBarrage');
	//弹幕数组
	var showLogArray = [];
	if (isBarrage == 'close') {
		setTimeout(function() {
			$('#webplayer').prevAll('div').remove();
			if ('undefined' != typeof showLogTimeout) {
				clearTimeout(showLogTimeout);
			}
		}, 10000)
	} else if (isBarrage == 'open') {
		// $('body').hide(1000).show(2000);
		// $('#chat_area').fadeOut($('#delayInputTextId').val()*2).fadeIn($('#delayInputTextId').val());
		showLogArray.push(text);
		createShowLogs();
	}
	//只能清理弹幕
	if ($('.showLog').length > 198) {
		console.log('清理屏幕弹幕');
		$('#webplayer').prevAll('div').remove();
		// for (var i=0;i<$('#webplayer').prevAll('div').length;i++){
		//     if ($('#webplayer').prevAll('div')[i].offsetLeft<=$('body').clientWidth/2){
		//         $('#webplayer').prevAll('div')[i].remove();
		//     }
		//
		// }
		// for (var i=0;i<$('#webplayer').prevAll('div').length;i++){
		//     if ($('#webplayer').prevAll('div')[i].offsetLeft<=($('#webplayer').prevAll('div')[i].length+20)){
		//         $('#webplayer').prevAll('div')[i].remove();
		//     }
		//
		// }
	}
	//创建dom
	function createShowLogs() {
		let webplayer = getDomById('webplayer');
		let chatBoxHeight = $('#chatbox').height();
		let htmlWidth = $('html').width();
		//每个dom应该的高度
		let topHeight = chatBoxHeight / 2 / showLogArray.length;
		// parseInt(Math.random() * 1000 / 1 + 1);
		//body的高度
		var bodyHeight = $('body').height();
		//根据数量布局
		for (let i = 0; i < showLogArray.length; i++) {
			let randomNo;

			function getRandNo() {
				randomNo = parseInt(Math.random() * bodyHeight / 1 + 1);
				if (document.getElementById('showLog' + randomNo) != null) {
					// console.log('重复的id：showLog'+randomNo+'正在重新创建');
					getRandNo();
					// $('#showLog' + randomNo).remove();
				}
				// console.log('不存在的id：showLog'+randomNo+'进入下一步');
				return randomNo;
			}
			//获得一个不重复的id
			randomNo = getRandNo();
			//清除重复的
			createSingleShowLog('showLog' + randomNo, showLogArray[i]);
			// $('#showLog' + (i + 1)).offset({top: topHeight * (i + 1),left:htmlWidth});
			$('#showLog' + randomNo).offset({
				// top: randomNo,
				left: htmlWidth
			});
			runShowLog('#showLog' + randomNo);
			// domArrary.push();


			// showLogArray.remove('11');
			// showLogArray.remove(showLogArray[i]);

			// showLogArray. shift();
		}
		// runShowLog('#showLog1');
		//创建单个dom
		function createSingleShowLog(id, text) {
			let showLogDivDom = document.createElement('div');

			//showLogDivDom.style.color = $('#background_color').val()
			showLogDivDom.style.color = getRandomColor();
			// showLogDivDom.style.fontSize="300px";
			showLogDivDom.id = id;
			showLogDivDom.className = 'showLog';
			showLogDivDom.innerHTML = text;
			// showLogDivDom.style.backgroundColor='white';
			document.body.insertBefore(showLogDivDom, webplayer);
		}

	}


	//运行dom
	function runShowLog(id) {
		let i = $('html').width();
		// if ('undefined' != typeof showLogTimeout) {
		//     clearTimeout(showLogTimeout);
		// }    //隐藏所有


		//  var $chatboxLegt=$('#chatbox').offset().left;
		// var $domIdWidth= $(id).width();
		let delayInputTextId = $('#delayInputTextId').val();
		//弹幕速度时间范围delayInputTextId >= 1000 ? 1000 : delayInputTextId;
		let minDelay = 500;
		let maxDelay = 2000;
		let showLogDelay = delayInputTextId < minDelay || delayInputTextId > maxDelay ? delayInputTextId < minDelay ?
			minDelay : maxDelay : delayInputTextId;
		showLogSetTimeout(id);

		function showLogSetTimeout(id) {
			var showLogTimeout = setTimeout(function() {
				//突出显示
				i -= 200;
				console.log($(id).css("backgroundColor"));
				$(id).offset({
					left: i
				});
				//10秒后自动隐藏
				// setTimeout(function () {
				//     $(id).hide();
				// }, 10000);
				if (i > -$(id).width())
					showLogSetTimeout(id);
				//删除已经显示的
				// deleteShowLog(id);
			}, showLogDelay);
		}
	}


	// 销毁dom
	function deleteShowLog(id) {
		// console.log(id);
		$(id).remove();
		$('body:first-child').remove();
		// $(id).empty();
		console.log(showLogArray.length);
		// if(showLogArray.length>1){
		if ('undefined' != typeof showLogTimeout) {
			clearTimeout(showLogTimeout);
		}
		showLogArray.shift();
		// }

		console.log(showLogArray)
	}


};
// document.querySelector("#write_area").removeEventListener('cut', test1);
// document.querySelector("#write_area").removeEventListener('paste', test1);
// document.querySelector("#write_area").removeEventListener('copy', test1);


// document.getElementById("write_area").removeEventListener('cut', test1);
// document.getElementById("write_area").removeEventListener('paste', test1);
// document.getElementById("write_area").removeEventListener('copy', test1);



// let ele = document.querySelector("#write_area");
// //这里给匿名函数临时指定一个名字，执行完毕后移除监听器。
// ele.addEventListener('copy', func=(event)=> {
//     ele.removeEventListener('hidden.bs.modal', func);
// });
// ele.addEventListener('cut', func=(event)=> {
//     ele.removeEventListener('hidden.bs.modal', func);
// });

// ele.addEventListener('paste', func=(event)=> {
//     ele.removeEventListener('hidden.bs.modal', func);
// });

// var writeArea=document.getElementById("write_area");
// writeArea.addEventListener('copy', func = (event) => {
// 	writeArea.removeEventListener('hidden.bs.modal', func);
// });


// var writeArea=document.getElementById("write_area");
// writeArea.oncut=function(e){
// 	console.log("oncut",e);
// }
// writeArea.oncopy=function(e){
// 	console.log("oncopy",e);
// }
// writeArea.onpaste=function(e){
// 	console.log("onpaste",e);
// }


// console.log("afreecatv.test.js");
// window.onload = function() {
// 	console.log("window.onload");

// 	$("#write_area").off("paste").off("cut").off("copy");
// }
