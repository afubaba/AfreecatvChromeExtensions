// document.addEventListener('DOMContentLoaded', function() {
//     var checkPageButton = document.getElementById('clickIt');
//     checkPageButton.addEventListener('click', function() {
  
//       chrome.tabs.getSelected(null, function(tab) {
//         alert("Hello..! It's my first chrome extension.");

//          chrome.tabs.sendRequest(tab.id, { action:  "GetBaiduKeyWord"  },  function  (response) {
//              alert(response.kw);
//          });
//       });
//     }, false);
//   }, false);