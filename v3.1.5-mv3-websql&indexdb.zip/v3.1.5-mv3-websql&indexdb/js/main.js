// console.log("main.js");

[].map.call(document.getElementsByTagName('img'), function(img) {
	return img.src;
});
