// document.addEventListener('DOMContentLoaded', function() {
//     var checkPageButton = document.getElementById('clickIt');
//     checkPageButton.addEventListener('click', function() {
  
//       chrome.tabs.getSelected(null, function(tab) {
//         alert("Hello..! It's my first chrome extension.");

//          chrome.tabs.sendRequest(tab.id, { action:  "GetBaiduKeyWord"  },  function  (response) {
//              alert(response.kw);
//          });
//       });
//     }, false);
//   }, false);

//设置时间
setDomTimeById("timeFrequencys");
// const rnName = chrome.i18n.getMessage(name);
// var errorDetails1="3."
// var errorDetails2="1.3"
// console.log(chrome.i18n.getMessage("error", [errorDetails1,errorDetails2]));
// console.log(chrome.i18n.getMessage("version", [errorDetails1,errorDetails2]));
const host = "https://afubaba.github.io/Afreecatv/";
//加载的时候语言
var setLang = {
    getI18n: function (name) {
        const rnName = chrome.i18n.getMessage(name);
        return rnName;
    },
    setLanguage: function (idName) {
        let rnNameId = "popup_" + idName;
        //获取本地化值
        let rnName = this.getI18n(rnNameId);
        // console.log(rnNameId);
        // console.log(rnName);
        // console.log("#" + idName);
        if (rnName != "") {

            $("#" + idName).html(rnName);
        }
        //获取本地化值Title
        let rmNameTitleValue = rnNameId + "_title";
        rmNameTitleValue = this.getI18n(rmNameTitleValue);
        if (rmNameTitleValue != "") {
            $("#" + idName).attr("title", rmNameTitleValue);
        }
    },
    setLanguageByName: function ($nameString, nameValue) {
        let rnNameId = "popup_" + nameValue;
        //获取本地化值
        let rnName = this.getI18n(rnNameId);

        if (rnName != "") {
            $($nameString).html(rnName);
        }
        //获取本地化值Title
        let rmNameTitleValue = rnNameId + "_title";
        rmNameTitleValue = this.getI18n(rmNameTitleValue);
        if (rmNameTitleValue != "") {
            $($nameString).attr("title", rmNameTitleValue);
        }
    }
}
document.addEventListener('DOMContentLoaded', function () {
    /*使用手册*/
    //i18n
    // const idNameAarray = ["userManual"];
    setLang.setLanguage("userManual");
    //语言
    const pageLang = chrome.i18n.getMessage("pageLang");
    let userManualPdf;
    if (pageLang == "zh") {
        userManualPdf = host+"libs/pdf/扩展使用手册.pdf";
    } else if (pageLang == "ko") {
        userManualPdf = host+"libs/pdf/확장 사용 설명서.pdf";
    }

    $("#userManualLink").attr("href", userManualPdf);

}, false);