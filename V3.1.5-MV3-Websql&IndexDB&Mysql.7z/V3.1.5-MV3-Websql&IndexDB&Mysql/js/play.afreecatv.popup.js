// console.log("popub.js");

/* 
var httpRequest = new XMLHttpRequest();
httpRequest.open('GET', 'http://quan.suning.com/getSysTime.do', true);
httpRequest.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
httpRequest.send(null);
httpRequest.onreadystatechange = function() {
	if (httpRequest.readyState == 4 && httpRequest.status == 200) {
		var json = httpRequest.responseText;
		alert(json);
	}
};
 */


chrome.runtime.onMessage.addListener(
    function (request, sender, sendResponse) {
        console.log(request)
        if (request.action == "Hi") {
            console.log("11");
            alert("11");

            sendResponse({kw: "1"});
        }
    });

function httpRequest(url, callback) {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", url, true);
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4) {
            callback(xhr.responseText);
        }
    }
    xhr.send();
}

//通用发消息到Play.afreecatv.js所有窗口
async function sendMessageToPlayAfreecatv(actionData) {
    chrome.tabs.query({
        // 'active': false,
        'url': ["*://play.afreecatv.com/*"]
    }, function (tabs) {
        console.log(tabs.length)
        tabs.forEach(function (tab) {
            chrome.tabs.sendMessage(
                tab.id, actionData,
                function (response) {
                    console.log(response);
                });
        })

    });

}


//刷新时查找当前窗口的数据
function sendMessageToPlayAfreecatvForSearchData(actionData, callback) {
    chrome.tabs.query({
        'active': true,
        'url': ["*://play.afreecatv.com/*"]
    }, function (tabs) {

        chrome.tabs.sendMessage(
            tabs[0].id, actionData,
            function (response) {
                callback(response);
                // alert(response.kw);
            });
        // console.log("刷新窗口个数:"+tabs.length);
        // tabs.forEach(function (tab) {
        //     chrome.tabs.sendMessage(
        //         tab.id, actionData,
        //         function (response) {
        //             callback(response);
        //             // alert(response.kw);
        //         });
        // })

    });
}


//时间
setDomTimeById("timeFrequencys");
/* nowTime全局变量 */
/* setTimeout(function(){
	alert(nowTime);
},2000);
 */
const host = "https://afubaba.github.io/Afreecatv/";
document.addEventListener('DOMContentLoaded', function () {
    /*使用手册*/
    //i18n
    // const idNameAarray = ["userManual"];
    // setLang.setLanguage("userManual");
    const popup_userManual = chrome.i18n.getMessage("popup_userManual");
    const popup_userManual_title = chrome.i18n.getMessage("popup_userManual_title");
    $("#userManual").html(popup_userManual).attr("title",popup_userManual_title);

    //语言
    const pageLang = chrome.i18n.getMessage("pageLang");
    let userManualPdf;
    if (pageLang == "zh") {
        userManualPdf = host+"libs/pdf/扩展使用手册.pdf";
    } else if (pageLang == "ko") {
        userManualPdf = host+"libs/pdf/확장 사용 설명서.pdf";
    }
    $("#userManualLink").attr("href", userManualPdf);

    //popup功能
    // getDomById("timeFrequencys").innerHTML=
    //清空聊天
    var clearChatarea = getDomById("clearChatarea");
    clearChatarea.onclick = function () {
        const confirm_tip = setLang.getI18n("play_afreecatv_popup_clearChatarea_confirm_tip");
        const isClearChatarea = confirm(confirm_tip);
        if (isClearChatarea) {
            sendMessageToPlayAfreecatv({
                action: "clearChatarea"
            });
        }

    }
    //录音机模式
    let $recorderModeLabel = $("#recorderModeLabel");
    let $recorderMode = $("#recorderMode");
    $recorderMode.change(function () {
        if ($recorderMode.prop("checked")) {
            const confirm_tip = setLang.getI18n("play_afreecatv_popup_recorderMode_confirm_tip");
            const isRecorderMode = confirm(confirm_tip);
            if (isRecorderMode) {
                sendMessageToPlayAfreecatv({
                    action: "recorderMode"
                });
                $("#recorderModeLabel").addClass("label-warning");
            } else {
                $recorderMode.prop("checked", false);
                $("#recorderModeLabel").removeClass("label-warning");
            }
        } else {
            sendMessageToPlayAfreecatv({
                action: "recorderMode"
            });
            $("#recorderModeLabel").removeClass("label-warning");
        }
    });
    let $deletePlayerLabel = $("#deletePlayerLabel");
    let $deletePlayer = $("#deletePlayer");
    $deletePlayer.change(function () {
        if ($deletePlayer.prop("checked")) {
            const confirm_tip = setLang.getI18n("play_afreecatv_popup_deletePlayer_confirm_tip");
            const isClosePlayer = confirm(confirm_tip);
            if (isClosePlayer) {
                sendMessageToPlayAfreecatv({
                    action: "deletePlayer"
                });
                $("#deletePlayerLabel").addClass("label-important");
            } else {
                $deletePlayer.prop("checked", false);
                $("#deletePlayerLabel").removeClass("label-important");
            }
        } else {
            sendMessageToPlayAfreecatv({
                action: "deletePlayer"
            });
            $("#deletePlayerLabel").removeClass("label-important");
        }
    });
    //查询开关状态同步
    sendMessageToPlayAfreecatvForSearchData({
        searchData: "test"
    }, function (response) {
        let recorderModeStatus = response.recorderModeStatus;
        let isDeletePlayerStatus = response.isDeletePlayerStatus;
        if (recorderModeStatus == "true") {
            $recorderMode.prop("checked", true);
            $("#recorderModeLabel").addClass("label-warning");
        } else {
            $recorderMode.prop("checked", false);
            $("#recorderModeLabel").removeClass("label-warning");
        }
        if (isDeletePlayerStatus == "true") {
            $deletePlayer.prop("checked", true);
            $("#deletePlayerLabel").addClass("label-important");
        } else {
            $deletePlayer.prop("checked", false);
            $("#deletePlayerLabel").removeClass("label-important");
        }
    });

    // var recorderMode = getDomById("recorderMode");
    // recorderMode.onclick = function() {
    // 	// "确认关闭播放器吗，关闭后需要刷新页面才能恢复"
    // 	const confirm_tip = setLang.getI18n("play_afreecatv_popup_recorderMode_confirm_tip");
    // 	const isRecorderMode = confirm(confirm_tip);
    // 	if (isRecorderMode) {
    // 		sendMessageToPlayAfreecatv({
    // 			action: "recorderMode"
    // 		});
    // 	}
    //
    // }
    //删除播放器
    // var deletePlayer = getDomById("deletePlayer");
    // deletePlayer.onclick = function() {
    // 	// "确认关闭播放器吗，关闭后需要刷新页面才能恢复"
    // 	const confirm_tip = setLang.getI18n("play_afreecatv_popup_deletePlayer_confirm_tip");
    // 	const isClosePlayer = confirm(confirm_tip);
    // 	if (isClosePlayer) {
    // 		sendMessageToPlayAfreecatv({
    // 			action: "deletePlayer"
    // 		});
    // 	}
    //
    // }

    //背景色
    // var background_color = getDomById("background_color");
    // background_color.onchange = function() {
    // 	sendMessageToPlayAfreecatv({
    // 		action: "changeBackColor",
    // 		"color": this.value
    // 	});
    // }
    //背景圖片
    // var background = getDomById("background");
    // background.onchange = function() {
    // 	sendMessageToPlayAfreecatv({
    // 		action: "changeBackground",
    // 		"background": this.value
    // 	});
    // }


    var testAjax = document.getElementById('testAjax');
    testAjax.addEventListener('click', function () {
        //chrome-extension://injfdmecbfhelnehplnlfpmkmnpbnkam/play.afreecatv.popup.html
        // chrome-extension://injfdmecbfhelnehplnlfpmkmnpbnkam/_locales/ko/messages.json
        //const msgUrl = chrome.runtime.getURL("_locales/zh/messages.json");
        // const msgUrl = "_locales/zh/messages.json";
        const msgUrl = "https://afubaba.github.io/Afreecatv/json/emoji.json";

        alert(msgUrl);

        // httpRequest(msgUrl, function(result) {

        // 	// var str = eval(result);
        // 	alert(result.extName)
        // 	alert(result)


        // 	 var str = JSON.parse(result);
        // 	alert(str);

        // });


        $.ajax({
            url: msgUrl,
            type: 'get',
            // dataType: "JSONP",
            success: function (result, statis) {
                alert(result);
                document.write(result)
                // var str = JSON.stringify(result);
                // document.write(str);

                // eval(result);
                // var str = JSON.parse(result);
                // alert(str);
                //转换json字符串为json对象
                //方式一：
                // var obj = eval("("+data+")");
                // //方式二：
                // var obj2 = JSON.parse(data);

                // 	//转为json对象可以直接点属性
                // 	console.log(obj.name);
                // 	console.log(obj2.name);

                // 建议使用第二种JSON.parse()，第一种麻烦，且存在注入执行代码的风险。


            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                // var XMLHttpRequest = JSON.stringify(XMLHttpRequest);

                alert(XMLHttpRequest.responseText);
                alert(textStatus);
                alert(errorThrown);
            }
        });


    });

    // $("#changeLanguageSelect").change(function(){
    //   alert("chufa");
    //   $(this).css("background-color","#FFFFCC");
    // });
    //扩展接收内容脚本的消息
    // chrome.runtime.onMessage.addListener(
    //   function  (request, sender, sendResponse) {

    //       alert(document.getElementById("testMatchs").innerHTML);

    //       sendResponse({ response:"nihao"});

    //   });

    //mv2
    // chrome.tabs.sendRequest(tab.id, { action:  "Test"  },  function  (response) {
    //   alert(response.kw);
    // });
    //MV3
    //  chrome.tabs.query({'active': true, 'lastFocusedWindow': true}, function(tab){
    //   alert("Hello..! It's my first chrome extension.");
    // chrome.runtime.sendMessage(
    //  tab.id, { action:  "Test"  } ,  function  (response) {
    //   alert(response);
    // });
    // });
    //拓展发送消息到内容脚本
    var testSendMessage = document.getElementById('testSendMessage');
    testSendMessage.addEventListener(
        'click',
        function () {
            chrome.tabs.query({
                'active': true,
                'lastFocusedWindow': true
            }, function (tab) {

                chrome.tabs.sendMessage(
                    tab[0].id, {
                        action: "Test"
                    },
                    function (response) {
                        alert(response.kw);
                    });

            });
        }, false);


    var checkPageButton = document.getElementById('clickIt');
    checkPageButton.addEventListener('click',
        function () {
            chrome.tabs.query({
                'active': true,
                'lastFocusedWindow': true
            }, function (tab) {
                alert("Hello..! It's my first chrome extension.");
                chrome.runtime.sendMessage(
                    tab.id, {
                        action: "Background"
                    },
                    function (response) {
                        var str = JSON.stringify(response);
                        alert(str);
                    });


            });
        }, false);


    var testClick = document.getElementById('testClick');
    testClick.addEventListener('click',
        function () {
            chrome.tabs.query({
                'active': true,
                'lastFocusedWindow': true
            }, function (tabs) {
                // );
                //注入css
                console.log(tabs[0].id)
                (tabs[0].id);
                alert(str);

                chrome.scripting.insertCSS({
                    target: {
                        tabId: tabs[0].id
                    },
                    css: "css/style.css",
                });

                //注入函数
                function text() {
                    alert("text");
                }

                chrome.scripting.executeScript({
                    target: {
                        tabId: tabs[0].id
                    },
                    files: ["js/baidu.js"],
                    func: text()
                });
                //注入函数
                const color = "red"

                function changeBackgroundColor(backgroundColor) {
                    document.body.style.backgroundColor = backgroundColor;
                }

                chrome.scripting.executeScript({
                    target: {
                        tabId: tabs[0].id
                    },
                    func: changeBackgroundColor,
                    args: [color],
                });


            });
        }, false);
    var testMatchs = document.getElementById("testMatchs");
    testMatchs.addEventListener('click',
        function () {

        }, false);


    //加载的时候语言
    var setLang = {
        getI18n: function (name) {
            const rnName = chrome.i18n.getMessage(name);
            return rnName;
        },
        setLanguage: function (idName) {
            var rnNameId = "play_afreecatv_popup_" + idName;
            //获取本地化值
            var rnName = this.getI18n(rnNameId);
            if (rnName != "") {
                $("#" + idName).html(rnName);
            }
            //获取本地化值Title
            var rmNameTitleValue = rnNameId + "_title";
            rmNameTitleValue = this.getI18n(rmNameTitleValue);
            if (rmNameTitleValue != "") {
                $("#" + idName).attr("title", rmNameTitleValue);
            }
        }
    }
    window.onload = function () {

        /* var individualization = getDomById("individualization"); */
        // alert(this.value);
        /* var tt = chrome.i18n.getMessage("individualization", "nihao"); */
        // alert(chrome.i18n.getMessage("individualization", "ko"))
        /* individualization.innerHTML = tt; */
        console.log("play.pop:");
        var play_afreecatv_lang = chrome.i18n.getMessage("play_afreecatv_popup_lang", "nihao");
        getDomById("language").innerHTML = play_afreecatv_lang;

        const idNameAarray = ["recorderModeSpan", "deletePlayerSpan", "clearChatarea", "timeButtonId"];
        idNameAarray.forEach(function (idName) {
            setLang.setLanguage(idName);
        });


    }


    // var changeLanguageSelect = getDomById("changeLanguageSelect");
    // changeLanguageSelect.onchange =function() {
    //
    // 		// alert(this.value)
    // 		//个性化
    // 		var individualization = getDomById("individualization");
    // 		alert(this.value);
    // 		var tt = chrome.i18n.getMessage("individualization", this.value);
    // 		alert(chrome.i18n.getMessage("individualization", "ko"))
    // 		individualization.innerHTML = tt;
    //
    // 	};
    // $(changeLanguageSelect).change(function(){
    // 	alert("jq函数");
    // })

    // changeLanguageSelect.addEventListener("change", function(){
    // 	Change()
    // });
    // async function Change() {
    // 	alert("出发函数");
    // }
    // function changeLanguagesFunction() {

    // 	var changeLanguageSelect = getDom('changeLanguageSelect');


    // 	// 中文
    // 	// chinese={'text':'内容'};
    // 	// 韩语
    // 	// korean ={'text':'内容'}

    // }
}, false);

// var changeLanguageSelect = document.getElementById('changeLanguageSelect');
//  changeLanguageSelect.addEventListener('click', function() {
//     alert("1");
//  });
function timeButtonFunction() {
    setTimeout(function () {
        if (!document.getElementById('timeButtonId').className.includes('collapsed')) {
            $('#autoTimeId').click();
        } else {
            clearInterval(autoInterval);
        }
    }, 2000);
}

//自动发送实际
function getTimeFunction() {

    //判断当计时器是否重复
    if ('undefined' != typeof handTimeout) {
        clearInterval(handTimeout);
    }
    console.log('now times start');
    date = new Date();
    fullYear = date.getFullYear();
    month = date.getMonth() + 1;
    day = date.getDate();
    //小时+1
    hours = date.getHours() + 1;
    //hours=date.getHours();
    minutes = date.getMinutes();
    seconds = date.getSeconds();
    //判断如果加一天，才执行减少一天
    isAddDay = false;
    var handTimeout = setTimeout(function () {
        if (hours >= 24) {
            hours = 0;
        }
        //韩国1点减去一天
        if (0 < hours < 1) {
            //韩国12点增加一天
            day++;
            //判断如果加一天，才执行减少一天
            isAddDay = true;
        }

        //判断如果加一天，才执行减少一天
        if (hours > 1 && isAddDay == true) {
            day--;
            isAddDay == false;
        }

        //当月最大的天数
        var monthArrays1 = [1, 3, 5, 7, 8, 10, 12]; //31days
        var monthArrays2 = [4, 6, 9, 11]; //30days
        var monthArrays3 = 2; //28days
        maxDays = 0;
        if (monthArrays3 == month) {
            maxDays = 28;
        } else if (monthArrays2.includes(month)) {
            maxDays = 30;
        } else {
            maxDays = 31;
        }

        if (day > maxDays) {

            day = 1;
            month++;
        }
        if (month > 12) {
            month=1;
            fullYear++;
        }
        var now = fullYear + '-' + month + '-' + day + '\t' + hours + ':' + minutes + ':' + seconds;
        // var nowTimes=now.replaceAll('0','₀').replaceAll('1','₁')
        //     .replaceAll('2','₂').replaceAll('3','₃').replaceAll('4','₄')
        //     .replaceAll('5','₅').replaceAll('6','₆').replaceAll('7','₇')
        //     .replaceAll('8','₈').replaceAll('9','₉');
        getNowTime(now, hours, minutes);
    }, 100);

    function getNowTime(now, hours, minutes) {
        var oclock;
        if (hours == 12 || hours == 0 && minutes >= 0 && minutes <= 29) {
            oclock = '🕛';
        } else if (hours == 12 || hours == 0 && minutes >= 30 && minutes <= 59) {
            oclock = '🕧';
        } else if (hours == 1 || hours == 13 && minutes >= 0 && minutes <= 29) {
            oclock = '🕐';
        } else if (hours == 1 || hours == 13 && minutes >= 30 && minutes <= 59) {
            oclock = '🕜';
        } else if (hours == 2 || hours == 14 && minutes >= 0 && minutes <= 29) {
            oclock = '🕑';
        } else if (hours == 2 || hours == 14 && minutes >= 30 && minutes <= 59) {
            oclock = '🕝';
        } else if (hours == 3 || hours == 15 && minutes >= 0 && minutes <= 29) {
            oclock = '🕒';
        } else if (hours == 3 || hours == 15 && minutes >= 30 && minutes <= 59) {
            oclock = '🕞';
        } else if (hours == 4 || hours == 16 && minutes >= 0 && minutes <= 29) {
            oclock = '🕓';
        } else if (hours == 4 || hours == 16 && minutes >= 30 && minutes <= 59) {
            oclock = '🕟';
        } else if (hours == 5 || hours == 17 && minutes >= 0 && minutes <= 29) {
            oclock = '🕔';
        } else if (hours == 5 || hours == 17 && minutes >= 30 && minutes <= 59) {
            oclock = '🕠';
        } else if (hours == 6 || hours == 18 && minutes >= 0 && minutes <= 29) {
            oclock = '🕕';
        } else if (hours == 6 || hours == 18 && minutes >= 30 && minutes <= 59) {
            oclock = '🕡';
        } else if (hours == 7 || hours == 19 && minutes >= 0 && minutes <= 29) {
            oclock = '🕖';
        } else if (hours == 7 || hours == 19 && minutes >= 30 && minutes <= 59) {
            oclock = '🕢';
        } else if (hours == 8 || hours == 20 && minutes >= 0 && minutes <= 29) {
            oclock = '🕗';
        } else if (hours == 8 || hours == 20 && minutes >= 30 && minutes <= 59) {
            oclock = '🕣';
        } else if (hours == 9 || hours == 21 && minutes >= 0 && minutes <= 29) {
            oclock = '🕘';
        } else if (hours == 9 || hours == 21 && minutes >= 30 && minutes <= 59) {
            oclock = '🕤';
        } else if (hours == 10 || hours == 22 && minutes >= 0 && minutes <= 29) {
            oclock = '🕙';

        } else if (hours == 10 || hours == 22 && minutes >= 30 && minutes <= 59) {
            oclock = '🕥';
        } else if (hours == 11 || hours == 23 && minutes >= 0 && minutes <= 29) {
            oclock = '🕚';
        } else if (hours == 11 || hours == 23 && minutes >= 30 && minutes <= 59) {
            oclock = '🕦';
        } else {
            oclock = '한국시간:';
        }
        // document.getElementById('write_area').innerHTML=nowTimes;
        document.getElementById('write_area').innerHTML = oclock + ':' + now;

        //自定义输入框的值
        //document.getElementById('testInput').value=now;
        //发送框框的值
        document.getElementById('btn_send').click();
    }

}
