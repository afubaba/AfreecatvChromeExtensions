// console.log("本地common.js");
function httpRequest(url, callback) {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", url, true);
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4) {
            callback(xhr.responseText);
        }
    }
    xhr.send();
}

//获取任意dom对象
function getDomById(domId) {
    domId = document.getElementById(domId);
    return domId;
}

function getDomByName(domName) {
    domName = document.getElementsByName(domName);
    return domName;
}

function getDomByClassName(domClassName) {
    domClassName = document.getElementsByClassName(domClassName);
    return domClassName;
}

var dx = {
    "sfz": function (id) {
        var domId = document.getElementById(id);
        return domId;
    },
    "lx": function (className) {
        var className = document.getElementsByClassName(className);
        return className;
    },
    "nm": function (name) {
        var name = document.getElementsByClassName(name);
        return name;
    }
}
var dynamicLoading = {
    css: function (path) {
        if (!path || path.length === 0) {
            throw new Error('argument "path" is required !');
        }
        var head = document.getElementsByTagName('head')[0];
        var link = document.createElement('link');
        link.href = path;
        link.rel = 'stylesheet';
        link.type = 'text/css';
        head.appendChild(link);
    },
    js: function (path) {
        if (!path || path.length === 0) {
            throw new Error('argument "path" is required !');
        }
        var head = document.getElementsByTagName('head')[0];
        var script = document.createElement('script');
        // script.async = "async";
        script.defer = "defer";
        script.src = path;
        script.type = 'text/javascript';
        head.appendChild(script);
    }
};

//转换指定字符串为韩国时间
function getDateTimeFormate(date) {
    if (!date) {
        return
    } else {

        var d = new Date(date);
        var fullYear = d.getFullYear();
        var month = ('0' + (d.getMonth() + 1)).slice(-2);
        var day = ('0' + (d.getDate())).slice(-2);
        var hours = ('0' + (d.getHours())).slice(-2);
        var minutes = ('0' + (d.getMinutes())).slice(-2);
        var seconds = ('0' + (d.getSeconds())).slice(-2);
        var now;
        var addHour;

        var webLang = navigator.language;
        if (webLang.includes("zh")) {
            //判断如果加一天，才执行减少一天
            isAddDay = false;

            addHour = 1;
            hours = ('0' + (d.getHours() + 1)).slice(-2);

            if (hours >= 24) {
                hours = 0;
            }
            //韩国1点减去一天
            if (0 < hours < 1) {
                //韩国12点增加一天
                day++;
                //判断如果加一天，才执行减少一天
                isAddDay = true;
            }

            //判断如果加一天，才执行减少一天
            if (hours > 1 && isAddDay == true) {
                day--;
                isAddDay == false;
            }

            //当月最大的天数
            var monthArrays1 = [1, 3, 5, 7, 8, 10, 12]; //31days
            var monthArrays2 = [4, 6, 9, 11]; //30days
            var monthArrays3 = 2; //28days
            maxDays = 0;
            if (monthArrays3 == month) {
                maxDays = 28;
            } else if (monthArrays2.includes(month)) {
                maxDays = 30;
            } else {
                maxDays = 31;
            }

            if (day > maxDays) {

                day = 1;
                month++;
            }
            if (month > 12) {
                month = 1;
                fullYear++;
            }


        } else if (webLang == "ko") {
            addHour = 0;
        } else {
            addHour = 0;
        }
        //拼接时间
        now = fullYear + '-' + month + '-' + day + ' ' + hours + ':' + minutes + ':' + seconds;
        console.log(now);
        return now;
    }
}

// 网络时间
function dateTimeFormate(date) {
    if (!date) {
        return
    } else {

        var d = new Date(date);
        var fullYear = d.getFullYear();
        var month = ('0' + (d.getMonth() + 1)).slice(-2);
        var day = ('0' + (d.getDate())).slice(-2);
        var hours = ('0' + (d.getHours())).slice(-2);
        var minutes = ('0' + (d.getMinutes())).slice(-2);
        var seconds = ('0' + (d.getSeconds())).slice(-2);
        var now;
        var addHour;

        var webLang = navigator.language;
        if (webLang.includes("zh")) {
            //判断如果加一天，才执行减少一天
            isAddDay = false;

            addHour = 1;
            hours = ('0' + (d.getHours() + 1)).slice(-2);

            if (hours >= 24) {
                hours = 0;
            }
            //韩国1点减去一天
            if (0 < hours < 1) {
                //韩国12点增加一天
                day++;
                //判断如果加一天，才执行减少一天
                isAddDay = true;
            }

            //判断如果加一天，才执行减少一天
            if (hours > 1 && isAddDay == true) {
                day--;
                isAddDay == false;
            }

            //当月最大的天数
            var monthArrays1 = [1, 3, 5, 7, 8, 10, 12]; //31days
            var monthArrays2 = [4, 6, 9, 11]; //30days
            var monthArrays3 = 2; //28days
            maxDays = 0;
            if (monthArrays3 == month) {
                maxDays = 28;
            } else if (monthArrays2.includes(month)) {
                maxDays = 30;
            } else {
                maxDays = 31;
            }

            if (day > maxDays) {

                day = 1;
                month++;
            }
            if (month > 12) {
                month = 1;
                fullYear++;
            }


        } else if (webLang == "ko") {
            addHour = 0;
        } else {
            addHour = 0;
        }
        //拼接时间
        now = fullYear + '-' + month + '-' + day + '\t' + hours + ':' + minutes + ':' + seconds;


        try {
            // var isAutoTimeStart = getDomByName('isAutoTimeStart');

            let $halfHourPrompt = $("#halfHourPrompt");
            //开关判断
            if ($halfHourPrompt.prop("checked")) {
                var text_information = '';
                var nickName = '';

                // if (minutes==29&&seconds==57||minutes==59&&seconds==57) {
                //}
                if (minutes == 30 && seconds == 0 || minutes == 0 && seconds == 0) {
                    var oclock;
                    if (hours == 12 || hours == 0 && minutes == 0) {
                        oclock = '🕛';
                    } else if (hours == 12 || hours == 0 && minutes == 30) {
                        oclock = '🕧';
                    } else if (hours == 1 || hours == 13 && minutes == 0) {
                        oclock = '🕐';
                    } else if (hours == 1 || hours == 13 && minutes == 30) {
                        oclock = '🕜';
                    } else if (hours == 2 || hours == 14 && minutes == 0) {
                        oclock = '🕑';
                    } else if (hours == 2 || hours == 14 && minutes == 30) {
                        oclock = '🕝';
                    } else if (hours == 3 || hours == 15 && minutes == 0) {
                        oclock = '🕒';
                    } else if (hours == 3 || hours == 15 && minutes == 30) {
                        oclock = '🕞';
                    } else if (hours == 4 || hours == 16 && minutes == 0) {
                        oclock = '🕓';
                    } else if (hours == 4 || hours == 16 && minutes == 30) {
                        oclock = '🕟';
                    } else if (hours == 5 || hours == 17 && minutes == 0) {
                        oclock = '🕔';
                    } else if (hours == 5 || hours == 17 && minutes == 30) {
                        oclock = '🕠';
                    } else if (hours == 6 || hours == 18 && minutes == 0) {
                        oclock = '🕕';
                    } else if (hours == 6 || hours == 18 && minutes == 30) {
                        oclock = '🕡';
                    } else if (hours == 7 || hours == 19 && minutes == 0) {
                        oclock = '🕖';
                    } else if (hours == 7 || hours == 19 && minutes == 30) {
                        oclock = '🕢';
                    } else if (hours == 8 || hours == 20 && minutes == 0) {
                        oclock = '🕗';
                    } else if (hours == 8 || hours == 20 && minutes == 30) {
                        oclock = '🕣';
                    } else if (hours == 9 || hours == 21 && minutes == 0) {
                        oclock = '🕘';
                    } else if (hours == 9 || hours == 21 && minutes == 30) {
                        oclock = '🕤';
                    } else if (hours == 10 || hours == 22 && minutes == 0) {
                        oclock = '🕙';

                    } else if (hours == 10 || hours == 22 && minutes == 30) {
                        oclock = '🕥';
                    } else if (hours == 11 || hours == 23 && minutes == 0) {
                        oclock = '🕚';
                    } else if (hours == 11 || hours == 23 && minutes == 30) {
                        oclock = '🕦';
                    } else {
                        oclock = '한국시간';
                    }
                    //赋值 昵称
                    text_information = document.getElementsByClassName('text_information');
                    nickName = text_information.item(0).children[0].textContent;
                    // console.log('@' + nickName + ':오빠는 당신을 생각 나게/휘파람/');
                    // console.log(oclock + ':' + now);
                    document.getElementById('write_area').innerHTML = '@' + nickName + ':오빠는 당신을 생각 나게/휘파람/';
                    document.getElementById('btn_send').click();
                    document.getElementById('write_area').innerHTML = oclock + ':' + now;
                    document.getElementById('btn_send').click();
                }
            }
        } catch {

        }


        return now;


    }
}

function setDomTimeById(domTimeId) {

    setDomTimeInterval = setInterval(function () {
        var xhr = new XMLHttpRequest();
        if (!xhr) {
            xhr = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xhr.open("HEAD", "https:www.afreecatv.com", true);
        xhr.onreadystatechange =
            function () {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    /* alert(xhr.responseText);
                    alert(xhr.getResponseHeader("Date")); */
                    /* alert(dateTimeFormate(xhr.getResponseHeader("Date"))); */
                    nowTime = dateTimeFormate(xhr.getResponseHeader(
                        "Date"));
                    getDomById(domTimeId).innerHTML = nowTime;
                    //版本校验
                    if (localStorageType == "indexdb") {
                        if(typeof opIndexDB!=="undefined"){
                            opIndexDB.versionSynchronization();
                        }
                    }
                }
            }
        xhr.send(null);
    }, 1000);
}

// var dx = {
// 	"sfz": function(id) {
// 		var domId = document.getElementById(id);
// 		return domId;
// 	},
// 	"lx": function(className) {
// 		var className = document.getElementsByClassName(className);
// 		return className;
// 	},
// 	"nm": function(name) {
// 		var name = document.getElementsByClassName(name);
// 		return name;
// 	}
// }


// // 网络时间
// function dateTimeFormate(date) {
// 	if (!date) {
// 		return
// 	} else {
// 		var d = new Date(date);
// 		var year = d.getFullYear();
// 		var month = ('0' + (d.getMonth() + 1)).slice(-2);
// 		var day = ('0' + (d.getDate())).slice(-2);
// 		var hour = ('0' + (d.getHours())).slice(-2);
// 		var minutes = ('0' + (d.getMinutes())).slice(-2);
// 		var seconds = ('0' + (d.getSeconds())).slice(-2);
// 		return year + "-" + month + "-" + day + " " + hour + ":" + minutes + ":" + seconds;
// 	}
// }

// function setDomTimeById(domTimeId) {
// 	setInterval(function() {
// 		var xhr = new XMLHttpRequest();
// 		if (!xhr) {
// 			xhr = new ActiveXObject("Microsoft.XMLHTTP");
// 		}
// 		xhr.open("HEAD", "https://afreecatv.com", true);
// 		xhr.onreadystatechange =
// 			function() {
// 				if (xhr.readyState == 4 && xhr.status == 200) {
// 					/* alert(xhr.responseText);
// 					alert(xhr.getResponseHeader("Date")); */
// 					/* alert(dateTimeFormate(xhr.getResponseHeader("Date"))); */
// 					nowTime = dateTimeFormate(xhr.getResponseHeader(
// 						"Date"));
// 					getDomById(domTimeId).innerHTML = nowTime;
// 				}
// 			}
// 		xhr.send(null);
// 	}, 1000);
// }

