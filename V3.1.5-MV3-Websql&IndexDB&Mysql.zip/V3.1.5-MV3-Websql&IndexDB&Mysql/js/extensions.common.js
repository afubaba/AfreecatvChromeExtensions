//通用发消息到Play.afreecatv.js
// console.log("extensions.common.js");
async function sendMessageToPlayAfreecatv(actionName) {
	chrome.tabs.query({
		/* 'active': true, */
		'url': ["*://play.afreecatv.com/*"]
	}, function(tabs) {
		tabs.forEach(function(tab) {
			chrome.tabs.sendMessage(
				tab.id, actionName,
				function(response) {
					// alert(response);
				});
		});
	});
}
//加载的时候语言
var setLang = {
	getI18n: function(name) {
		const rnName = chrome.i18n.getMessage(name);
		return rnName;
	},
	setLanguage: function(idName,prefix) {
		var rnNameId = prefix + idName;
		//获取本地化值
		var rnName = this.getI18n(rnNameId);
		if (rnName != "") {
			$("#" + idName).html(rnName);
		}
		//获取本地化值Title
		var rmNameTitleValue = rnNameId + "_title";
		rmNameTitleValue = this.getI18n(rmNameTitleValue);
		if (rmNameTitleValue != "") {
			$("#" + idName).attr("title", rmNameTitleValue);
		}
	},
	dataEach: function(dataArray,prefix) {
		dataArray.forEach(function(idName) {
			setLang.setLanguage(idName,prefix);
		});
	},
	setLanguageByName: function ($nameString, nameValue) {
		let rnNameId = "play_afreecatv_" + nameValue;
		//获取本地化值
		let rnName = this.getI18n(rnNameId);
		if (rnName != "") {
			$($nameString).html(rnName);
		}
		//获取本地化值Title
		let rmNameTitleValue = rnNameId + "_title";
		rmNameTitleValue = this.getI18n(rmNameTitleValue);
		if (rmNameTitleValue != "") {
			$($nameString).attr("title", rmNameTitleValue);
		}
	}
}
