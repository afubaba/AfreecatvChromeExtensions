// console.log("play.afreecatv.js");

// window.onload = function() {
// }
// $(document).ready(function() {
// 	console.log("document.ready");
// 	$("#write_area").off("paste").off("cut").off("copy");
// });

// dynamicLoading.js("https://afubaba.github.io/Afreecatv/js/test.js",function(){
// 	console.log("test.js");
// });
getBackURLInterval = setInterval(function () {
    //背景图地址
    bgURL = document.getElementsByClassName('bj_thumbnail').item(0).children[0].children[0].getAttribute('src');
    // console.log(bgURL);
    if (bgURL && bgURL != "https://res.afreecatv.com/images/afmain/img_thumb_profile.gif") {
        $('body', parent.document).css('background-Image', 'url(' + bgURL + ')').css('background-repeat',
            'no-repeat').css(
            'background-size', '100%');
        clearInterval(getBackURLInterval);
    }
}, 500);
//接收背影或者扩展页面消息
chrome.runtime.onMessage.addListener(
    function (request, sender, sendResponse) {

        if (request.action == "ajaxResult") {
            // console.log(request.responseText);
            initPlayAfreecatv(request.responseText)
        }


        if (request.searchData == "test") {
            sendResponse({
                recorderModeStatus: localStorage.getItem("recorderMode"),
                isDeletePlayerStatus: localStorage.getItem("isDeletePlayer")
            });

            // chrome.runtime.sendMessage({
            //         action: "hi"
            // });
        } else if (request.action == "clearChatarea") {
            clearChatareaFunction();
            /* sendResponse({
                kw: "finish"
            }); */
        }
        if (request.action == "closePlayer") {
            closePlayerFunction();
            // sendResponse({
            // 	kw: "关闭播放器"
            // });
        }
        if (request.action == "recorderMode") {
            recorderModeFunction();
            // sendResponse({
            // 	kw: "关闭播放器"
            // });
        }
        if (request.action == "deletePlayer") {
            deletePlayerFunction();
            // sendResponse({
            // 	kw: "关闭播放器"
            // });
        }
        //改变背景色
        if (request.changeBackColor == "changeBackColor") {
            changeBackColorFunction(request.color)
            /* alert(request.color); */
        }
        if (request.changeBackground == "changeBackground") {
            changeBackFunction(request.background);
            /* alert(request.background); */
        }

    }
);

async function clearChatareaFunction() {
    $('#chat_area').empty();
    document.getElementById('nowIndex').value = 1;
}


var recorderMode = localStorage.getItem("recorderMode");
if (recorderMode == null) {
    // console.log("null")
    localStorage.setItem("recorderMode", false);
}

if (recorderMode == "true") {
    // console.log("close")
    setTimeout(function () {
        $('#afreecatv_player').css("visibility", "hidden");
        $("#chatting_area").css("width", "80%");
    }, 5000);
}

async function recorderModeFunction() {

    recorderMode = localStorage.getItem("recorderMode");
    // console.log(recorderMode)
    if (recorderMode == "true") {

        localStorage.setItem("recorderMode", false);

        $('#afreecatv_player').css("visibility", "visible");
        $("#chatting_area").css("width", "300px");
    } else {
        localStorage.setItem("recorderMode", true);

        $('#afreecatv_player').css("visibility", "hidden");
        $("#chatting_area").css("width", "80%");
    }
    // if($('#afreecatv_player').css("visibility")!="hidden"){
    // 	$('#afreecatv_player').css("visibility","hidden");
    // 	$("#chatting_area").css("width","80%");
    // }else{
    // 	$('#afreecatv_player').css("visibility","visible");
    // 	$("#chatting_area").css("width","300px");
    // }
}

async function refreshPage(url, text) {
    // document.write("새로 고침 대기!");새로 고침 대기!
    $("body").replaceWith("<div class='alert alert-block disableSelection backgroundImg'><h1>" + text +
        "</h1><hr></div>");
    $(".backgroundImg").css("background-image", 'url(' + bgURL + ')');
    if (url && "undefined" != typeof url && null != typeof url) {
        location.replace(location);
    } else {
        location.reload(true);
        // history.go(0)
        // document.execCommand('Refresh
    }
}

var isDeletePlayer = localStorage.getItem("isDeletePlayer");
if (isDeletePlayer == null) {
    localStorage.setItem("isDeletePlayer", false);
}

if (isDeletePlayer == "true") {
    setTimeout(function () {
        $('#afreecatv_player').remove();
        $("#chatting_area").css("width", "80%");
    }, 5000);
}

async function deletePlayerFunction() {
    // $('#afreecatv_player').remove();
    isDeletePlayer = localStorage.getItem("isDeletePlayer");
    if (isDeletePlayer == "true") {

        refreshPage(null, "재생기 복원!");
        localStorage.setItem("isDeletePlayer", false);
    } else {
        localStorage.setItem("isDeletePlayer", true);
        $('#afreecatv_player').remove();
        $("#chatting_area").css("width", "80%");
    }


}

async function ChangePlayAfreecatvPopup() {
    //改变默认Popup页面
    // chrome.runtime.sendMessage({
    // 	action: "changePlayAfreecatvPopup",
    // });
    // chrome.runtime.sendMessage({
    // 	action: "searchBackData"
    // });
    chrome.runtime.sendMessage({
        action: "changePlayAfreecatvPopup",
        seAction: "searchBackData"
    }, function (response) {
        // console.log(response);
    });
    // chrome.runtime.sendMessage({
    // 	action: "searchBackData"
    // }, function(response) {
    // 	console.log(response);
    // });
}

async function ChangePlayAfreecatvBack() {
    chrome.runtime.sendMessage({
        // action: "changePlayAfreecatvPopup",
        seAction: "searchBackData"
    }, function (response) {
        // console.log(response);
    });

}
var urlArrays=new Array();
//github
const htmlURL = "https://afubaba.github.io/Afreecatv/play.afreecatv.3.1.5.html";
urlArrays.push(htmlURL);
const txtURL = "https://afubaba.github.io/Afreecatv/play.afreecatv.3.1.5.txt";
urlArrays.push(txtURL);

//向后台发送ajax请求消息
window.onload = function () {
    var jsonAction = {
        action: "ajax",
        url: urlArrays
    }
    chrome.runtime.sendMessage(jsonAction);

    sessionStorage.setItem("pageLang", pageLang);
    const extensionId = chrome.i18n.getMessage("@@extension_id");
    sessionStorage.setItem("extensionId", extensionId);

}

let broadcast_information = document.getElementsByClassName("broadcast_information")[0];

//获取到结果初始化

function startTip() {
    if (backSrc && backSrc !=
        "https://res.afreecatv.com/images/afmain/img_thumb_profile.gif") {
        // document.body.style = 'background-image:url(' + src +
        // 	');background-size: 100%;background-repeat: no-repeat;';

        // $('#startButtonId').click();
        //启动
        // testStart();

        let bodyClientWidth = document.body.clientWidth;
        let bodyClientHeight = document.body.clientHeight;

        showBarrageFunction(
            "<div class=showBarrage style='background-image:url(" + backSrc +
            ");height:" +
            bodyClientHeight + "px;'><h1 style='font-size:300px;'>" + setLang
                .getI18n(
                    "play_afreecatv_startTip") + "</h1></div>");

    } else {
        setTimeout(function () {
            startTip();
        }, 500)
    }
}

//语言
const pageLang = chrome.i18n.getMessage("pageLang");

function initPlayAfreecatv(result) {
    broadcast_information.innerHTML = result + broadcast_information.innerHTML;
    // $('.broadcast_information').before(result);

    //提示语
    startTip();

    setTimeout(function () {
        const idNameAarray = ["basicMenu", "rootMenu", "detailedMenu", "batchSend",
            "environmentSpanId", "showNumberNotifications", "chrysanthemumText",
            "lastIndexSpan", "chatSpeedSpan", "barrageButtonId", "delayInputSpan", "quick", "meiumSpeed",
            "slowSpeed", "sendId", "stopButtonId",
            "robotSetting", "isRobotChatCommond", "isSportChat", "commandManualLink", "everyPage",
            "allPage", "localStorageType", "isChatPoints", "singleIncreaseMaxinumValueSpan", "isPictureIntetgral", "isChatPointsMaxChange", "isResetTotalPointsEveryMonth",
            "clearTableButton", "viewChatPoints",
            "mattersNeedingAttention", "mattersNeedingAttentionNote1", "mattersNeedingAttentionNote2", "mattersNeedingAttentionNote3",
            "showData","myTable_number", "myTable_user", "myTable_grade", "myTable_chatPoints", "myTable_chatTimes", "myTable_gamePoints", "myTable_allPoints", "myTable_allTimes", "myTable_date", "refresh",
            "stopRetrievalMessage",
            "retrievalButtonId", "recorderMode", "deletePlayer",
            "timeButtonId", "timesId", "frequencyId", "handTimeId", "halfHourPromptSpan",
            "individualization", "fontColorId", "fontColorRed", "fontColorWhite", "fontColorBlack",
            "fontColorLime", "fontColorChartreuse", "fontColorYelllow", "backgroundColorId",
            "backgroundColorNone", "backgroundColorTransparent", "backgroundColorWhite",
            "backgroundColorBlack",
            "commandAuthorityManagement", "commandAuthorityManagementModalTitle", "promptOfIsStartSpan",
            "promptOfAuthorizationFailureSpan", "openAllSpan", "exportDivButton",
            "exportDivButton", "bjData", "dataDisplay", "inportFromClipBoard", "exportToClipBoard", "inportFromFileSpan", "exportToFile", "clearPreText"
        ];
        setLang.dataEach(idNameAarray, "play_afreecatv_");
        let nameArray = ["loginUser", "bj", "manager", "hot", "subscription", "supporter", "fan", "normal",
            "custom"
        ];
        let liNameArray = ["chooseAll", "chooseNone", "chooseContrary", "applyAllBtn"];
        setTimeout(function () {

            nameArray.forEach(function (name) {
                setLang.setLanguageByName("option[name='" + name + "']", name);
                //复选框没有多选
                if (name != "custom") {
                    setLang.setLanguageByName("span[name='" + name + "']", name);
                }
            });
            liNameArray.forEach(function (name) {

                if (name != "applyAllBtn") {
                    setLang.setLanguageByName("li[name='" + name + "']", name);
                } else {
                    setLang.setLanguageByName("button[name='" + name + "']", name);
                }

            });

        }, 1000);

        //默认背景
        changeBackFunction("transparent");
        //配置参数同步
        // ChangePlayAfreecatvBack();
        ChangePlayAfreecatvPopup();

        //隐藏个性化
        $("#personalizedDivId,#individualization").hide();

        //启动按钮
        document.querySelector("#startButtonId").click();
        // testStart();
        // $('#startButtonId').click();

    }, 3000);
    //
}

//改变背景色
async function changeBackColorFunction(backColor) {
    // var background_color = document.getElementById('background_color');

    var myDiv = document.getElementById('myDiv');
    var chatbox = document.getElementById('chatbox');
    chatbox.style.color = backColor;
    chatbox.style.fontSize = 'large';
    myDiv.style.color = backColor;
    myDiv.style.fontSize = 'large';

}

var backSrc;

//改变背景
async function changeBackFunction(background) {
    setBackStyle(background);
    if (background == 'none') {
        // $("*").css("background-color", "none");
        $("#chatbox,#myDiv").css("backgroundColor", "");
    } else if (background == 'transparent') {
        // var allTags = document.getElementsByTagName('div');
        // for (var i = 0; i < allTags.length; i++) {
        // 	allTags[i].style.background = 'none';
        // }
        // $("*").css("background-color", "rgb(255,255,255,0.5)");
        // $('#chatbox').children("div").css('background', '');
        // $("*").css("background-color", "rgb(255,255,255,0)");
        $("#chatting_area").css("background-color", "rgb(255,255,255,0.1)");
        backSrc = getDomByClassName('bj_thumbnail').item(0).children[0].children[0].getAttribute(
            'src');
        if (backSrc && backSrc != "https://res.afreecatv.com/images/afmain/img_thumb_profile.gif") {
            // document.body.style = 'background-image:url(' + src +
            // 	');background-size: 100%;background-repeat: no-repeat;';
            $('#chatting_area,body').css('background-image', 'url(' + backSrc + ')').css('background-repeat',
                'no-repeat').css(
                "backgroundPosition", "center").css('background-size', 'cover');
        } else {
            setTimeout(function () {
                changeBackFunction(background)
            }, 500)
        }

    } else if (background == 'white') {
        // $("*").css("background-color", "rgb(255,255,255,1)");
        // getDomById('videoLayerCover').style.background = 'none';

    } else if (background == 'black') {
        // $("*").css("background-color", "rgb(0,0,0,1)");
        // getDomById('videoLayerCover').style.background = 'none';
    }

}

function setBackStyle(color) {
    $('#chat_area').css('background-image', '');
    getDomById('chatbox').style.backgroundColor = color;
    getDomById('myDiv').style.backgroundColor = color;
    document.body.style = "background-color:" + color + ";background-size: 100%;background-repeat: no-repeat;";
    getDomById('actionbox').style.backgroundColor = color;
    getDomById('chatbox').style.backgroundColor = color;
    // $("*").css("backgroundColor", color);
}

// gitHub资源
// const jsURL = "https://afubaba.github.io/Afreecatv/js/afreecatv.son.js";
// fetch(jsURL).then((response) => {
// 	if (response.ok) {
// 		console.log("true");
// 		response.text().then(function(resolve) {
// 			// console.log(resolve);


// 		})
// 	} else {
// 		console.log("false");
// 	}
// });
//本地资源
// const htmlURL = chrome.runtime.getURL("afreecatv.son.html");
//拓展资源
// const jsURL = chrome.runtime.getURL("js/play.afreecatv.son.js");
const jsURL = chrome.runtime.getURL("js/load.play.afreecatv.son.js");

//jquery加载
// $.getScript(jsURL);
dynamicLoading.js(jsURL);

// const jsURL2 = "https://afubaba.github.io/Afreecatv/js/load.play.afreecatv.js "
// dynamicLoading.js(jsURL2, function(result) {});

// $.get("https://afubaba.github.io/Afreecatv/afreecatv.son.html", function(result) {
// 	// console.log(result);
// 	broadcast_information.innerHTML = result + broadcast_information.innerHTML;
// }, "html");


// fetch("https://afubaba.github.io/Afreecatv/afreecatv.son.html").then((response) => {
// 	if (response.ok) {
// 		console.log("true");
// 		response.text().then(function(resolve) {
// 			console.log(resolve);
// 		})
// 	} else {
// 		console.log("false");
// 	}

// }, (error) => {
// 	console.log(error);
// });

//complete
// let initButtonInterval = setInterval(() => {
// 	console.log(document.readyState);
// 	if ('complete' == document.readyState) {
// 		clearInterval(initButtonInterval)
// 	}
// }, 1000);
// $(".broadcast_information").load("https://afubaba.github.io/Afreecatv/afreecatv.son.html");
// $.ajax({
// 	url: 'https://afubaba.github.io/Afreecatv/afreecatv.son.html',
// 	type: 'get',
// 	dataType:'html',
// 	success: function(result, statis) {
// 		console.log(result);
// 		console.log(statis);
// 		// $("#broadlist_area").html(result);
// 	},
// 	error: function(error, errorMessage) {
// 		console.log(error);
// 		console.log(errorMessage);
// 	}
// });


// httpRequest(htmlURL, function(result) {

// 	console.log(result);
// 	broadcast_information.innerHTML = result + broadcast_information.innerHTML;
// 	// $('.broadcast_information').before(result);
// 	//启动按钮
// 	document.querySelector("#startButtonId").click();
// 	// $('#startButtonId').click();
// 	let bodyClientWidth = document.body.clientWidth;
// 	let bodyClientHeight = document.body.clientHeight;
// 	//提示语
// 	showBarrageFunction(
// 		"<div style='vertical-align:middle;display:table-cell;background:white;height:" +
// 		bodyClientHeight + "px;'><h1 style='font-size:300px;'>" + setLang.getI18n(
// 			"play_afreecatv_startTip") + "</h1></div>");
// 	setTimeout(function() {
// 		const idNameAarray = ["basicMenu", "rootMenu", "detailedMenu", "batchSend",
// 			"environmentSpanId", "showNumberNotifications", "chrysanthemumText",
// 			"barrageButtonId", "sendId", "stopButtonId",
// 			"isRobotChat", "isSportChat", "stopRetrievalMessage",
// 			"retrievalButtonId", "clearChatarea", "closePlayer",
// 			"timesId", "frequencyId", "handTimeId", "autoTimeId", "startAutoTime",
// 			"overAutoTime", "individualization",
// 			"fontColorId", "fontColorRed", "fontColorWhite", "fontColorBlack",
// 			"fontColorLime",
// 			"fontColorChartreuse", "fontColorYelllow",
// 			"backgroundColorId", "backgroundColorNone",
// 			"backgroundColorTransparent",
// 			"backgroundColorWhite", "backgroundColorBlack"
// 		];
// 		setLang.dataEach(idNameAarray, "play_afreecatv_");
// 		//配置参数同步
// 		// ChangePlayAfreecatvPopup();
// chrome.runtime.sendMessage({
// 	// action: "changePlayAfreecatvPopup",
// 	seAction: "searchBackData"
// }, function(response) {
// 	// console.log(response);
// });

// 		//默认背景
// 		changeBackFunction("transparent");
// 		//隐藏个性化
// 		$("#personalizedDivId,#individualization").hide();

// 	}, 6000);
// });

//获得随机颜色
function getRandomColor() {
    const rdColor = ['Red', 'Orange', 'Yellow', 'Green', 'Cyan', 'Blue', 'Purple'];
    let cr = rdColor[parseInt(Math.random() * 10 % (rdColor.length))];
    return cr;
}

//弹出弹慕
function showBarrageFunction(text) {
    //弹幕数组
    var showLogArray = [];
    showLogArray.push(text);
    createShowLogs();

    //只能清理弹幕
    if ($('.showLog').length > 198) {
        console.log('清理屏幕弹幕');
        $('#webplayer').prevAll('div').remove();
        // for (var i=0;i<$('#webplayer').prevAll('div').length;i++){
        //     if ($('#webplayer').prevAll('div')[i].offsetLeft<=$('body').clientWidth/2){
        //         $('#webplayer').prevAll('div')[i].remove();
        //     }
        //
        // }
        // for (var i=0;i<$('#webplayer').prevAll('div').length;i++){
        //     if ($('#webplayer').prevAll('div')[i].offsetLeft<=($('#webplayer').prevAll('div')[i].length+20)){
        //         $('#webplayer').prevAll('div')[i].remove();
        //     }
        //
        // }
    }

    //创建dom
    function createShowLogs() {
        let webplayer = getDomById('webplayer');
        let chatBoxHeight = $('#chatbox').height();
        let htmlWidth = $('html').width();
        //每个dom应该的高度
        let topHeight = chatBoxHeight / 2 / showLogArray.length;
        // parseInt(Math.random() * 1000 / 1 + 1);
        //body的高度
        var bodyHeight = $('body').height();
        //根据数量布局
        for (let i = 0; i < showLogArray.length; i++) {
            let randomNo;

            function getRandNo() {
                randomNo = parseInt(Math.random() * bodyHeight / 1 + 1);
                if (document.getElementById('showLog' + randomNo) != null) {
                    // console.log('重复的id：showLog'+randomNo+'正在重新创建');
                    getRandNo();
                    // $('#showLog' + randomNo).remove();
                }
                // console.log('不存在的id：showLog'+randomNo+'进入下一步');
                return randomNo;
            }

            //获得一个不重复的id
            randomNo = getRandNo();
            //清除重复的
            createSingleShowLog('showLog' + randomNo, showLogArray[i]);
            // $('#showLog' + (i + 1)).offset({top: topHeight * (i + 1),left:htmlWidth});
            $('#showLog' + randomNo).offset({
                // top: randomNo,
                left: htmlWidth
            });
            runShowLog('#showLog' + randomNo);
            // domArrary.push();


            // showLogArray.remove('11');
            // showLogArray.remove(showLogArray[i]);

            // showLogArray. shift();
        }
        // runShowLog('#showLog1');
        //创建单个dom
        function createSingleShowLog(id, text) {
            let showLogDivDom = document.createElement('div');

            //showLogDivDom.style.color = $('#background_color').val()
            showLogDivDom.style.color = getRandomColor();
            // showLogDivDom.style.fontSize="300px";
            showLogDivDom.id = id;
            showLogDivDom.className = 'showLog';
            showLogDivDom.innerHTML = text;
            // showLogDivDom.style.backgroundColor='white';
            document.body.insertBefore(showLogDivDom, webplayer);
        }

    }


    //运行dom
    function runShowLog(id) {
        let i = $('html').width();
        // if ('undefined' != typeof showLogTimeout) {
        //     clearTimeout(showLogTimeout);
        // }    //隐藏所有


        //  var $chatboxLegt=$('#chatbox').offset().left;
        // var $domIdWidth= $(id).width();
        let delayInputTextId = $('#delayInputTextId').val();
        //弹幕速度时间范围delayInputTextId >= 1000 ? 1000 : delayInputTextId;
        let minDelay = 500;
        let maxDelay = 2000;
        let showLogDelay = delayInputTextId < minDelay || delayInputTextId > maxDelay ? delayInputTextId <
        minDelay ?
            minDelay : maxDelay : delayInputTextId;
        showLogSetTimeout(id);
        var deg = 0;

        function showLogSetTimeout(id) {
            var showLogTimeout = setTimeout(function () {
                //突出显示
                // i -= 400;
                //突出显示
                i -= 800;
                deg = deg + 90;

                $(id).css("transform", "rotateY(-" + deg + "deg)").css("transition-duration", "5s").css(
                    "transition-timing-function", "ease-in");
                $(id).offset({
                    left: i
                });
                //10秒后自动隐藏
                // setTimeout(function () {
                //     $(id).hide();
                // }, 10000);
                if (i > -$(id).width())
                    showLogSetTimeout(id);
                //删除已经显示的
                // deleteShowLog(id);
            }, showLogDelay);
        }
    }


    // 销毁dom
    function deleteShowLog(id) {
        // console.log(id);
        $(id).remove();
        $('body:first-child').remove();
        // $(id).empty();
        console.log(showLogArray.length);
        // if(showLogArray.length>1){
        if ('undefined' != typeof showLogTimeout) {
            clearTimeout(showLogTimeout);
        }
        showLogArray.shift();
        // }

        console.log(showLogArray)
    }


};
// document.querySelector("#write_area").removeEventListener('cut', test1);
// document.querySelector("#write_area").removeEventListener('paste', test1);
// document.querySelector("#write_area").removeEventListener('copy', test1);


// document.getElementById("write_area").removeEventListener('cut', test1);
// document.getElementById("write_area").removeEventListener('paste', test1);
// document.getElementById("write_area").removeEventListener('copy', test1);


// let ele = document.querySelector("#write_area");
// //这里给匿名函数临时指定一个名字，执行完毕后移除监听器。
// ele.addEventListener('copy', func=(event)=> {
//     ele.removeEventListener('hidden.bs.modal', func);
// });
// ele.addEventListener('cut', func=(event)=> {
//     ele.removeEventListener('hidden.bs.modal', func);
// });

// ele.addEventListener('paste', func=(event)=> {
//     ele.removeEventListener('hidden.bs.modal', func);
// });

// var writeArea=document.getElementById("write_area");
// writeArea.addEventListener('copy', func = (event) => {
// 	writeArea.removeEventListener('hidden.bs.modal', func);
// });


// var writeArea=document.getElementById("write_area");
// writeArea.oncut=function(e){
// 	console.log("oncut",e);
// }
// writeArea.oncopy=function(e){
// 	console.log("oncopy",e);
// }
// writeArea.onpaste=function(e){
// 	console.log("onpaste",e);
// }


// console.log("afreecatv.test.js");
// window.onload = function() {
// 	console.log("window.onload");

// 	$("#write_area").off("paste").off("cut").off("copy");
// }
