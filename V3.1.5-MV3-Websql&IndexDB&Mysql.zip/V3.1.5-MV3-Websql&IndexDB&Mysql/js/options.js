// Save this script as `options.js`
// console.log("options.js");

// dynamicLoading.css("https://afubaba.github.io/Afreecatv/libs/bootstrap/2.3.2/css/bootstrap.min.css");
// dynamicLoading.js("https://afubaba.github.io/Afreecatv/libs/bootstrap/2.3.2/js/bootstrap.min.js");


// <link rel="stylesheet" type="text/css" href="libs/bootstrap/2.3.2/css/bootstrap.min.css"
// <script type="text/javascript" src="libs/bootstrap/2.3.2/js/bootstrap.min.js"></script>

// Saves options to localStorage.
function save_options() {
	var select = document.getElementById("color");
	var color = select.children[select.selectedIndex].value;
	localStorage["favorite_color"] = color;

	// Update status to let user know options were saved.
	var status = document.getElementById("status");
	status.innerHTML = "Options Saved.";
	setTimeout(function() {
		status.innerHTML = "";
	}, 750);
}

// Restores select box state to saved value from localStorage.
function restore_options() {
	var favorite = localStorage["favorite_color"];
	if (!favorite) {
		return;
	}
	var select = document.getElementById("color");
	for (var i = 0; i < select.children.length; i++) {
		var child = select.children[i];
		if (child.value == favorite) {
			child.selected = "true";
			break;
		}
	}
}
/* document.addEventListener('DOMContentLoaded', restore_options); */
/* document.querySelector('#save').addEventListener('click', save_options); */






/* window.onload = function() {

	
}
 */
//查询回掉函数
// function seData(data) {
// 	console.log(data);
// }
document.addEventListener('DOMContentLoaded', function() {

	const idNameAarray = ["individualization",
		"fontColorId",
		"fontColorRed", "fontColorWhite", "fontColorBlack", "fontColorLime",
		"fontColorChartreuse", "fontColorYelllow",
		"backgroundColorId", "backgroundColorNone", "backgroundColorTransparent",
		"backgroundColorWhite", "backgroundColorBlack"
	];
	setLang.dataEach(idNameAarray,"options_");


	//声明数据
	const extensionId = chrome.i18n.getMessage("@@extension_id");
	//字体颜色
	var background_color = getDomById("background_color");
	//背景圖片
	var background = getDomById("background");
	var options = [{
		id: extensionId,
		fontColor: background_color.value,
		backColor: background.value,

	}];
	if ('indexedDB' in window) {
		// console.log("支持indexdb");
		//若对象含有存在的id则插入失败
		// opIndexDB.insertData("optiosDB", 1, "options", options);
		// opIndexDB.searchById(extensionId,"optiosDB", 1, "options");

		//首次查询显示
		opIndexDB.searchById(extensionId, "optiosDB", 1, "options");

		background_color.onchange = function() {

			//改变正在显示的
			/* 	sendMessageToPlayAfreecatv({
					action: "changeBackColor",
					"color": this.value
				}); */

			// console.log(getDomById("background").value);
			options[0].backColor = getDomById("background").value
			options[0].fontColor = this.value;
			opIndexDB.updateData(options[0], "optiosDB", 1, "options");

			sendMessageToPlayAfreecatv({
				changeBackground: "changeBackground",
				changeBackColor: "changeBackColor",
				"color": options[0].fontColor,
				"background": options[0].backColor
			});
		}

		background.onchange = function() {

			// opIndexDB.searchById(extensionId, "optiosDB", 1, "options");
			options[0].fontColor = getDomById("background_color").value;
			options[0].backColor = this.value;
			opIndexDB.updateData(options[0], "optiosDB", 1, "options");

			// sendMessageToPlayAfreecatv({
			// 	action: "changeBackground",
			// 	"background": this.value
			// });
			sendMessageToPlayAfreecatv({
				changeBackground: "changeBackground",
				changeBackColor: "changeBackColor",
				"color": options[0].fontColor,
				"background": options[0].backColor
			});

		}
	} else {
		console.log("游览器不支持indexdb");
	}


	//未使用
	function notUse() {
		if (window.openDatabase) {
			console.log("浏览器支持websql");
			// var db = openDatabase("appdb", "1.0", "appdatabase", 1024 * 1024 * 100, function(result) {
			// 	console.log("首页:创建数据库成功");
			// 	db = result;
			// });

			opWebsql.seachData("OPTIONS");



			//自动添加一个
			opWebsql.insertData(extensionId);

			// opWebsql.updateData(options[0], "OPTIONS");
			background_color.onchange = function() {

				options[0].backColor = getDomById("background").value
				options[0].fontColor = this.value;
				opWebsql.updateData(options[0], "OPTIONS");

				sendMessageToPlayAfreecatv({
					changeBackground: "changeBackground",
					changeBackColor: "changeBackColor",
					"color": options[0].fontColor,
					"background": options[0].backColor
				});
			}
			background.onchange = function() {

				options[0].fontColor = getDomById("background_color").value;
				options[0].backColor = this.value;
				opWebsql.updateData(options[0], "OPTIONS");

				sendMessageToPlayAfreecatv({
					changeBackground: "changeBackground",
					changeBackColor: "changeBackColor",
					"color": options[0].fontColor,
					"background": options[0].backColor
				});

			}

		} else {
			console.log("游览器不支持websql");
		}
	}



	// if ('indexedDB' in window) {
	// 	// 如果数据库不存在则创建，如果存在但是version更大，会自动升级不会复制原来的版本
	// 	console.log("支持indexdb储存");
	// 	getIndexDB("option.html", 1);
	// }
	// addOneLink();

	// var req =opIndexDB.getDB();
	// opIndexDB.createTable("TestDB", 1,"options");
	// opIndexDB.createTable("TestDB", 1, "options");


	// createDateabase("TestDB1", 1);

	// console.log("AccessLevel:",chrome.storage.AccessLevel);
	console.log("managed:", chrome.storage.managed);
	console.log("session:", chrome.storage.session);
	console.log("local:", chrome.storage.local);
	console.log("sync:", chrome.storage.sync);

	chrome.storage.local.set(options[0], function() {
		console.log('Value is set to ', options[0]);
	});
	var dataKey = "backColor";

	chrome.storage.local.get([dataKey,"id"], function(result) {
		console.log(result);
		// console.log(result.backColor.length+dataKey.length);
	});
	



}, false);
