 
 console.log("baidu.js");
