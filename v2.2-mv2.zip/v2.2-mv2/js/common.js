//获取任意dom对象
function getDomById(dom) {
	var dom = document.getElementById(dom);
	return dom;
}

function getDomByName(domName) {
	domName = document.getElementsByName(domName);
	return domName;
}


// 网络时间
function dateTimeFormate(date) {
	if (!date) {
		return
	} else {
		var d = new Date(date);
		var year = d.getFullYear();
		var month = ('0' + (d.getMonth() + 1)).slice(-2);
		var day = ('0' + (d.getDate())).slice(-2);
		var hour = ('0' + (d.getHours())).slice(-2);
		var minutes = ('0' + (d.getMinutes())).slice(-2);
		var seconds = ('0' + (d.getSeconds())).slice(-2);
		return year + "-" + month + "-" + day + " " + hour + ":" + minutes + ":" + seconds;
	}
}

function setDomTimeById(domTimeId) {
	setInterval(function() {
		var xhr = new XMLHttpRequest();
		if (!xhr) {
			xhr = new ActiveXObject("Microsoft.XMLHTTP");
		}
		xhr.open("HEAD", "https://afreecatv.com", true);
		xhr.onreadystatechange =
			function() {
				if (xhr.readyState == 4 && xhr.status == 200) {
					/* alert(xhr.responseText);
					alert(xhr.getResponseHeader("Date")); */
					/* alert(dateTimeFormate(xhr.getResponseHeader("Date"))); */
					nowTime = dateTimeFormate(xhr.getResponseHeader(
						"Date"));
					getDomById(domTimeId).innerHTML = nowTime;
				}
			}
		xhr.send(null);
	}, 1000);
}
