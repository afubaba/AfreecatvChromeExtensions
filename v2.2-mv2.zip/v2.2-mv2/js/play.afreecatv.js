/* console.log("play.afreecatv.js");
 */
function dateTimeFormate(date) {
	if (!date) {
		return
	} else {
		var d = new Date(date);
		var year = d.getFullYear();
		var month = ('0' + (d.getMonth() + 1)).slice(-2);
		var day = ('0' + (d.getDate())).slice(-2);
		var hour = ('0' + (d.getHours() + 1)).slice(-2);
		var minutes = ('0' + (d.getMinutes())).slice(-2);
		var seconds = ('0' + (d.getSeconds())).slice(-2);
		return year + "-" + month + "-" + day + " " + hour + ":" + minutes + ":" + seconds;
	}
}
var xhr = new XMLHttpRequest();
if (!xhr) {
	xhr = new ActiveXObject("Microsoft.XMLHTTP");
}
xhr.open("HEAD", location.href, true);
xhr.onreadystatechange = function() {
	if (xhr.readyState == 4 && xhr.status == 200) {
		console.log(xhr.getResponseHeader("Date"));
		console.log(dateTimeFormate(xhr.getResponseHeader("Date")));
	}
}
xhr.send(null);
/* alert($.ajax({
	async: false
}).getResponseHeader("Date"));

alert(dateTimeFormate($.ajax({
	async: false
}).getResponseHeader("Date")));

function dateTimeFormate(date) {
	if (!date) {
		return
	} else {
		var d = new Date(date);
		var year = d.getFullYear();
		var month = ('0' + (d.getMonth() + 1)).slice(-2);
		var day = ('0' + (d.getDate())).slice(-2);
		var hour = ('0' + (d.getHours())).slice(-2);
		var minutes = ('0' + (d.getMinutes())).slice(-2);
		var seconds = ('0' + (d.getSeconds())).slice(-2);
		return year + "-" + month + "-" + day + " " + hour + ":" + minutes + ":" + seconds;
	}
} */

async function ChangePlayAfreecatvPopup() {
	//改变默认Popup页面
	// chrome.runtime.sendMessage({
	// 	action: "changePlayAfreecatvPopup",
	// });
	// chrome.runtime.sendMessage({
	// 	action: "searchBackData"
	// });
	chrome.runtime.sendMessage({
		action: "changePlayAfreecatvPopup",
		seAction: "searchBackData"
	}, function(response) {

	});
	// chrome.runtime.sendMessage({
	// 	action: "searchBackData"
	// }, function(response) {
	// 	console.log(response);
	// });
}

window.onload = function() {
	// ChangePlayAfreecatvPopup();
}

// chrome.extension.onRequest.addListener( //监听扩展程序进程或内容脚本发送的请求
// 	function  (request, sender, sendResponse) {
// 		if( request.action ==  "Test" ) {
// 			// sendResponse({ kw: document.forms[0].wd.value });

// 			// console.log(document.getElementsByClassName("broadcast_information"));
// 			// alert(document.getElementsByClassName("broadcast_information"));
// 			// sendResponse({ kw:1});szKeyword
// 			// console.log(document.getElementById("szKeyword").value);
// 			// sendResponse({ kw:document.getElementsByClassName("broadcast_information")});
// 			sendResponse({ kw:document.body});
// 		}
// 	}
// 	);
//接收扩展脚本的命令
chrome.runtime.onMessage.addListener(
	function(request, sender, sendResponse) {


		if (request.action == "clearChatarea") {
			clearChatareaFunction();
			/* sendResponse({
				kw: "finish"
			}); */
		}
		if (request.action == "closePlayer") {
			closePlayerFunction();
			// sendResponse({
			// 	kw: "关闭播放器"
			// });
		}
		//改变背景色
		if (request.changeBackColor == "changeBackColor") {
			changeBackColorFunction(request.color)
			/* alert(request.color); */
		}
		if (request.changeBackground == "changeBackground") {
			changeBackFunction(request.background);
			/* alert(request.background); */
		}

	}
);
var dom;
//获取任意dom对象
function getDomById(dom) {
	dom = document.getElementById(dom);
	return dom;
}

function getDomByClassName(dom) {
	dom = document.getElementsByClassName(dom);
	return dom;
}


//改变背景色
async function changeBackColorFunction(backColor) {
	// var background_color = document.getElementById('background_color');

	var myDiv = document.getElementById('myDiv');
	var chatbox = document.getElementById('chatbox');
	chatbox.style.color = backColor;
	chatbox.style.fontSize = 'large';
	myDiv.style.color = backColor;
	myDiv.style.fontSize = 'large';

}



//改变背景
async function changeBackFunction(background) {
	setBackStyle(background);
	if (background == 'none') {
		// $("*").css("background-color", "none");
		$("#chatbox,#myDiv").css("backgroundColor", "");
	} else if (background == 'transparent') {
		// var allTags = document.getElementsByTagName('div');
		// for (var i = 0; i < allTags.length; i++) {
		// 	allTags[i].style.background = 'none';
		// }
		// $("*").css("background-color", "rgb(255,255,255,0.5)");
		// $('#chatbox').children("div").css('background', '');
		// $("*").css("background-color", "rgb(255,255,255,0)");
		$("#chatting_area").css("background-color", "rgb(255,255,255,0)");
		var src = getDomByClassName('bj_thumbnail').item(0).children[0].children[0].getAttribute(
			'src');
		if (src != "https://res.afreecatv.com/images/afmain/img_thumb_profile.gif") {
			document.body.style = 'background-image:url(' + src +
				');background-size: 100%;background-repeat: no-repeat;';
			$('#chat_area').css('background-image', 'url(' + src + ')').css('background-repeat', 'no-repeat').css(
				'background-size', '100%');
		} else {
			setTimeout(function() {
				changeBackFunction(background)
			}, 500)
		}

	} else if (background == 'white') {
		// $("*").css("background-color", "rgb(255,255,255,1)");
		// getDomById('videoLayerCover').style.background = 'none';

	} else if (background == 'black') {
		// $("*").css("background-color", "rgb(0,0,0,1)");
		// getDomById('videoLayerCover').style.background = 'none';
	}

}

function setBackStyle(color) {
	$('#chat_area').css('background-image', '');
	getDomById('chatbox').style.backgroundColor = color;
	getDomById('myDiv').style.backgroundColor = color;
	document.body.style = "background-color:" + color + ";background-size: 100%;background-repeat: no-repeat;";
	getDomById('actionbox').style.backgroundColor = color;
	getDomById('chatbox').style.backgroundColor = color;
	// $("*").css("backgroundColor", color);
}
async function clearChatareaFunction() {
	$('#chat_area').empty();
	document.getElementById('nowIndex').value = 1;
}

async function closePlayerFunction() {
	$('#afreecatv_player').remove();
}
document.addEventListener('DOMContentLoaded', function() {
	//获取任意dom对象
	function getDomById(dom) {
		var dom = document.getElementById(dom);
		return dom;
	}

}, false);


//内容脚本发消息到后台
// var btnSend=document.getElementById("btn_send");
// btnSend.onclick=function(){
// 	alert("btn_send");
// 	chrome.runtime.sendMessage( { action:  "Hellow"  } ,  function  (response) {
//        var str = JSON.stringify(response);
//        alert(str);
//      });
// }

// chrome.tabs.query({'active': true, 'lastFocusedWindow': true}, function(tab){
//      alert("Hello..! It's my first chrome extension.");
//      chrome.runtime.sendMessage(
//       tab.id, { action:  "Test"  } ,  function  (response) {
//        alert(response);
//      });
//    });


// chrome.tabs.insertCSS(tabId, {
// file: 'css/insert.css',
// allFrames: false,
// runAt: 'document_start'
// }, function(){
// console.log('The css has been inserted.');
// });

//加载背景图
/* var backUrl1 = "https://profile.img.afreecatv.com/LOGO/10/1057123999/1057123999.jpg";
var backUrl = "https://afubaba.github.io/Afreecatv/img/bg1.jpg";
const bgURL = chrome.runtime.getURL("img/11.png");
var headImg = $('.thum')[0];
var bgInterval = setInterval(function() {
	if (headImg.src != "https://res.afreecatv.com/images/afmain/img_thumb_profile.gif") {
		// $('body').css('background','url('+headImg.src+')').css('background-size','100%').css('height','100%').css('width','100%');
		bgBackgroundFunction('url(' + headImg.src + ')');
		clearInterval(bgInterval);
	}
}, 1000);
var bdBack = document.body; */

function bgBackgroundFunction(bgURL) {
	bdBack.style.backgroundImage = bgURL; //设置背景图的的地址
	bdBack.style.backgroundRepeat = "no-repeat"; //设置背景不平铺
	bdBack.style.backgroundPosition = "center"; //设置背景图的位置
	bdBack.style.backgroundSize = "cover"; //设置背景图像的尺寸 

}
//清除背景.css('background-repeat','no-repeat')
// $('*').css('background', 'none');

//$('body').css('background-image','url('+backUrl+')');
//本地
const htmlURL = chrome.runtime.getURL("afreecatv.son.html");
//子页面地址(在线)
// var sonWindowUrl = "https://afubaba.github.io/Afreecatv/afreecatv.son.html";


//移除播放器
// $('#afreecatv_player').remove();

// function getI18n(name) {
// 	const rnName = chrome.i18n.getMessage(name);
// 	return rnName;
// }
// var setLang = {
// 	setLanguage: function(idName) {
// 		var rnName = getI18n("play_afreecatv_" + idName);
// 		/* console.log(idName + ":" + rnName); */
// 		if (rnName != "") {
// 			$("#" + idName).html(rnName);
// 		}
// 	}
// }
//加载的时候语言
// var setLang = {
// 	getI18n: function(name) {
// 		const rnName = chrome.i18n.getMessage(name);
// 		return rnName;
// 	},
// 	setLanguage: function(idName) {
// 		var rnNameId = "play_afreecatv_" + idName;
// 		//获取本地化值
// 		var rnName = this.getI18n(rnNameId);
// 		if (rnName != "") {
// 			$("#" + idName).html(rnName);
// 		}
// 		//获取本地化值Title
// 		var rmNameTitleValue = rnNameId + "_title";
// 		rmNameTitleValue = this.getI18n(rmNameTitleValue);
// 		if (rmNameTitleValue != "") {
// 			$("#" + idName).attr("title", rmNameTitleValue);
// 		}
// 	}
// }
let initButtonInterval = setInterval(() => {
	// console.log(document.readyState);
	if ('complete' == document.readyState) {
		//$('head', myWindowName.document).append("<script>$.ajax({url: 'https://afubaba.github.io/test/frame.son.html',type: 'get',success: function(result, statis) {console.log($('.broadcast_information'));$('.broadcast_information').before(result);setTimeout(function() {$('#startButtonId').click();}, 3000);},error: function(error, errorMessage) {console.log(error);console.log(errorMessage);}});</script>");

		$.ajax({
			url: htmlURL,
			type: 'get',
			success: function(result, statis) {
				
				// console.log($('.broadcast_information'))	;
				/*	findGrandSon('.broadcast_information').before(result);*/
				$('.broadcast_information').before(result);
				//执行点击子窗口初始化
				let bodyClientWidth = document.body.clientWidth;
				let bodyClientHeight = document.body.clientHeight;
				//提示语
				showBarrageFunction(
					"<div style='vertical-align:middle;display:table-cell;background:white;height:" +
					bodyClientHeight + "px;'><h1 style='font-size:300px;'>" + setLang.getI18n(
						"play_afreecatv_startTip") + "</h1></div>");
				//i18n
				const idNameAarray = ["basicMenu", "rootMenu", "detailedMenu", "batchSend",
					"environmentSpanId", "showNumberNotifications", "chrysanthemumText",
					"barrageButtonId", "sendId", "stopButtonId",
					"isRobotChat", "isSportChat", "stopRetrievalMessage", "retrievalButtonId",
					"timesId", "frequencyId", "handTimeId", "autoTimeId", "startAutoTime",
					"overAutoTime"
				];
				// idNameAarray.forEach(function(idName) {
				// 	setLang.setLanguage(idName);
				// });

				setLang.dataEach(idNameAarray, "play_afreecatv_");

				//ㅁ ㅠ ㅊ ㅇ ㄷ ㄹ ㅎ ㅗ ㅑ ㅓ ㅏ ㅣ ㅡ ㅜ ㅐ ㅔ ㅂ ㄱ ㄴ ㅅ ㅕ ㅍ ㅈ ㅌ ㅛ ㅋ
				// https://bj.afreecatv.com/due0138
				//$("#user_nick").val("\uffbb\uffbb\uffbb\uffbb\uffbb\uffbb\uffbb\uffbb\uffbb\uffbb")
				//启动按钮
				$('#startButtonId').click();

				//默认背景
				changeBackFunction("transparent");
				//配置参数同步
				ChangePlayAfreecatvPopup();


				/*setTimeout(function() {
					$('#startButtonId').click();
				}, 3000);*/
				/*setTimeout(function() {
					$('#my_test').clone().insertBefore($('#write_area'))
					$('.my_test')[0].remove();
				}, 3000);*/

			},
			error: function(error, errorMessage) {
				console.log(error);
				console.log(errorMessage);
			}
		});

		clearInterval(initButtonInterval)
	}
}, 1000);

const bootstapCSSURL = chrome.runtime.getURL("css/bootstrap.min.css");

const jsURL = chrome.runtime.getURL("js/afreecatv.son.js");

const bootstapJSURL = chrome.runtime.getURL("js/bootstrap.min.js");

dynamicLoading.css(bootstapCSSURL);
dynamicLoading.js(jsURL);
dynamicLoading.js(bootstapJSURL);


//弹出弹慕

//获得随机颜色
function getRandomColor() {
	const rdColor = ['Red', 'Orange', 'Yellow', 'Green', 'Cyan', 'Blue', 'Purple'];
	let cr = rdColor[parseInt(Math.random() * 10 % (rdColor.length))];
	return cr;
}

function showBarrageFunction(text) {
	//弹幕数组
	var showLogArray = [];
	showLogArray.push(text);
	createShowLogs();
	//只能清理弹幕
	if ($('.showLog').length > 198) {
		console.log('清理屏幕弹幕');
		$('#webplayer').prevAll('div').remove();
		// for (var i=0;i<$('#webplayer').prevAll('div').length;i++){
		//     if ($('#webplayer').prevAll('div')[i].offsetLeft<=$('body').clientWidth/2){
		//         $('#webplayer').prevAll('div')[i].remove();
		//     }
		//
		// }
		// for (var i=0;i<$('#webplayer').prevAll('div').length;i++){
		//     if ($('#webplayer').prevAll('div')[i].offsetLeft<=($('#webplayer').prevAll('div')[i].length+20)){
		//         $('#webplayer').prevAll('div')[i].remove();
		//     }
		//
		// }
	}
	//创建dom
	function createShowLogs() {
		let webplayer = getDomById('webplayer');
		let chatBoxHeight = $('#chatbox').height();
		let htmlWidth = $('html').width();
		//每个dom应该的高度
		let topHeight = chatBoxHeight / 2 / showLogArray.length;
		// parseInt(Math.random() * 1000 / 1 + 1);
		//body的高度
		var bodyHeight = $('body').height();
		//根据数量布局
		for (let i = 0; i < showLogArray.length; i++) {
			let randomNo;

			function getRandNo() {
				randomNo = parseInt(Math.random() * bodyHeight / 1 + 1);
				if (document.getElementById('showLog' + randomNo) != null) {
					// console.log('重复的id：showLog'+randomNo+'正在重新创建');
					getRandNo();
					// $('#showLog' + randomNo).remove();
				}
				// console.log('不存在的id：showLog'+randomNo+'进入下一步');
				return randomNo;
			}
			//获得一个不重复的id
			randomNo = getRandNo();
			//清除重复的
			createSingleShowLog('showLog' + randomNo, showLogArray[i]);
			// $('#showLog' + (i + 1)).offset({top: topHeight * (i + 1),left:htmlWidth});
			$('#showLog' + randomNo).offset({
				// top: randomNo,
				left: htmlWidth
			});
			runShowLog('#showLog' + randomNo);
			// domArrary.push();


			// showLogArray.remove('11');
			// showLogArray.remove(showLogArray[i]);

			// showLogArray. shift();
		}
		// runShowLog('#showLog1');
		//创建单个dom
		function createSingleShowLog(id, text) {
			let showLogDivDom = document.createElement('div');

			//showLogDivDom.style.color = $('#background_color').val()
			showLogDivDom.style.color = getRandomColor();
			// showLogDivDom.style.fontSize="300px";
			showLogDivDom.id = id;
			showLogDivDom.className = 'showLog';
			showLogDivDom.innerHTML = text;
			// showLogDivDom.style.backgroundColor='white';
			document.body.insertBefore(showLogDivDom, webplayer);
		}

	}


	//运行dom
	function runShowLog(id) {
		let i = $('html').width();
		// if ('undefined' != typeof showLogTimeout) {
		//     clearTimeout(showLogTimeout);
		// }    //隐藏所有


		//  var $chatboxLegt=$('#chatbox').offset().left;
		// var $domIdWidth= $(id).width();
		let delayInputTextId = $('#delayInputTextId').val();
		//弹幕速度时间范围delayInputTextId >= 1000 ? 1000 : delayInputTextId;
		let minDelay = 500;
		let maxDelay = 2000;
		let showLogDelay = delayInputTextId < minDelay || delayInputTextId > maxDelay ? delayInputTextId < minDelay ?
			minDelay : maxDelay : delayInputTextId;
		showLogSetTimeout(id);

		function showLogSetTimeout(id) {
			var showLogTimeout = setTimeout(function() {
				//突出显示
				i -= 400;
				$(id).offset({
					left: i
				});
				//10秒后自动隐藏
				// setTimeout(function () {
				//     $(id).hide();
				// }, 10000);
				if (i > -$(id).width())
					showLogSetTimeout(id);
				//删除已经显示的
				// deleteShowLog(id);
			}, showLogDelay);
		}
	}


	// 销毁dom
	function deleteShowLog(id) {
		// console.log(id);
		$(id).remove();
		$('body:first-child').remove();
		// $(id).empty();
		console.log(showLogArray.length);
		// if(showLogArray.length>1){
		if ('undefined' != typeof showLogTimeout) {
			clearTimeout(showLogTimeout);
		}
		showLogArray.shift();
		// }

		console.log(showLogArray)
	}


};


// alert("popub.js");
// chrome.runtime.sendMessage('Hello', function(response){
//       alert(response);
// });
