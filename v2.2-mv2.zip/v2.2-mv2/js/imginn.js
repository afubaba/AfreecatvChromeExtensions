console.log("imginn.js");

window.onload = function() {
	$(".userinfo").append("<button id='autoScroll'>下啦</button>").append(
		"<input id='textId' value='0' type='text'/><button id='donwloadAll'>下载所有</button>");
	$("#autoScroll").click(function() {
		autoScroll();
	});
	$("#donwloadAll").click(function() {
		down(parseInt($("#textId").val()));
	});
}

function autoScroll() {
	//自动下来加载
	setInterval(function() {
		window.scrollTo(0, document.body.scrollHeight + 1);

	}, 500);
}
//下载
var i = 0;
var interval = 10000;

function down(i) {
	function download(src) {
		ww = window.open(src, "_blank", "ww");
		//加载页面后多少秒后下载
		let initWindowInterval = setInterval(function() {
			console.log(ww.document.readyState);
			if ('complete' == ww.document.readyState) {
				var downloads = ww.document.getElementsByClassName("downloads")[0].children[0];
				//console.log(downloads);
				//下一个按钮
				var next = ww.document.getElementsByClassName("swiper-button-next")[0];
				//共有多少个图片
				var nextLength = ww.document.getElementsByClassName("swiper-pagination-bullet").length
				/* for (var i = 1; i < nextLength; i++) {
					next.click();
					downloads.click();
				} */
				if (downloads) {
					downloads.click();
				} else {
					console.log("首次点击失败");
				}

				var j = 0;
				downloadInterval = setInterval(function() {

					j++;
					console.log(j);
					console.log(nextLength);
					console.log("下一个");
					if (nextLength) {
						next.click();
						setTimeout(function() {
							console.log("下载");
							downloads.click();
						}, 1000);
						if (j >= nextLength - 1) {
							//结束下载
							i++;
							clearInterval(downloadInterval);
							setTimeout(function() {
								//点击下载后关闭窗口
								ww.close();
								down(i);
							}, 2000)

						}

					} else {
						i++;
						clearInterval(downloadInterval);
						setTimeout(function() {

							//点击下载后关闭窗口
							ww.close();
							down(i);
						}, 2000)
						/* clearInterval(downloadInterval); */
						console.log("程序异常");
					}



				}, 1500);

				clearInterval(initWindowInterval);
			}
		}, 1000);
	}
	//download("/p/CZEWCVqhBrm/");

	//if('undefined' != typeof document.getElementsByClassName("download")[i].parentElement.previousSibling.children){

	try {
		//var domA=document.getElementsByClassName("download")[i].parentElement.previousSibling.children[0];
		//var src  =document.getElementsByClassName("download")[i].parentElement.previousSibling.children[0].href;
		var domImg = document.getElementsByClassName("img")[i + 1].children[0];
		var src = domImg.href;
		download(src);
	} catch (e) {
		console.log(e);
	}
	//}

	//总共post
	var postLength = document.getElementsByClassName("download").length;
	console.log("i=" + i + ",post:" +
		postLength + ",已经进行" + i * interval / 1000 + "秒,总时间:" + postLength *
		interval / 1000 + "秒");
	/* if (i >= document.getElementsByClassName("download").length) {
		clearInterval(downloadInterval);

		ww.close();
		console.log("终止计时器");
	} */


}
