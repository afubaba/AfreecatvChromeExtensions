// chrome.tabs.getCurrent(function(tab) {

// });
// chrome.tabs.query({
// 	'active': true,
// 	'currentWindow': true
// }, function(tab) {

// 	alert(JSON.stringify(tab));
// 	chrome.runtime.sendMessage({
// 		action: "changeAfreecatvIndexPopup",
// 		cTab: tab
// 	});
	
	// chrome.tabs.create({
	// 	url: chrome.runtime.getURL('popup.html'),
	// 	active: false
	// }, function(tab) {
	// 	// After the tab has been created, open a window to inject the tab
	// 	chrome.windows.create({
	// 		tabId: tab.id,
	// 		type: 'popup',
	// 		focused: true
	// 	});
	// });
// });

//改变默认Popup页面
//设置时间
setDomTimeById("timeFrequencys");