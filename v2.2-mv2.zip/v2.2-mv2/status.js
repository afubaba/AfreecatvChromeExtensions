//const TIMEOUT = 3 * 60 * 1000; // 3 minutes in milliseconds

// const TIMEOUT = 10000;
// setTimeout(() => {
//   alert("NIHAO");
//   chrome.action.setIcon({
//     path: getRandomIconPath(),
//   });
// }, TIMEOUT);
// chrome.alarms.create('alarmsTest', {
//     periodInMinutes:0.1,//如果设置了该属性，定时器将在由 when 或者 delayInMinutes 指定的初始时间后每隔 periodInMinutes 分钟触发。如果没有设置，定时器只会触发一次。
//     delayInMinutes:0.1 //以分钟为单位的时间长度，在指定时间之后将产生 onAlarm 事件。
// });
// var test = 1;
// chrome.alarms.get('alarmsTest', function(alarm) {
// 	console.log(test);
// 	console.log(alarm);
	
// });

// chrome.alarms.onAlarm.addListener(function (alarm){
// 	test++;
// 	console.log(test);
// 	console.log(alarm);
// });