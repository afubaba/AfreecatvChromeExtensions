//console.log("void.afreecatv.js");
var dynamicLoading = {
	css: function(path) {
		if (!path || path.length === 0) {
			throw new Error('argument "path" is required !');
		}
		var head = document.getElementsByTagName('head')[0];
		var link = document.createElement('link');
		link.href = path;
		link.rel = 'stylesheet';
		link.type = 'text/css';
		head.appendChild(link);
	},
	js: function(path, callback) {
		if (!path || path.length === 0) {
			throw new Error('argument "path" is required !');
		}
		var head = document.getElementsByTagName('head')[0];
		var script = document.createElement('script');
		// script.async = "async";
		// script.defer = "defer";
		script.src = path;
		script.type = 'text/javascript';
		script.onload = function() {
			callback();
		}
		head.appendChild(script);
	}
};
//dynamicLoading.css(domain + "css/common.css");


function setIcon(newSrc) {

	//发送图标 消息
	//修改图标
	$('link[rel="shortcut icon"]').attr('href', newSrc);

}


// 定义一个检查地址栏变化的函数
function checkUrlChange() {
	// 获取当前地址栏 URL
	var newUrl = window.location.href;
	
	// 检查地址栏 URL 是否发生变化
	if (newUrl !== currentUrl||faviconImg!=$('link[rel="shortcut icon"]').attr('href')) {
		// 地址栏发生了变化，执行相应的代码
		//console.log('地址栏发生变化');
		
		initCount = 0;
		getURL();

		// 更新当前地址栏 URL
		currentUrl = newUrl;
	}
}


//console.log($.fn.jquery);

var faviconImg;//全局图标链接
function getURL() {
	try {
		var imgSrc = $('.broadcast_information .bj_thumbnail img').attr('src');
		if (typeof imgSrc == "undefined" || imgSrc == "https://stimg.afreecatv.com/undefined") {

			if ($('.thumb img')) {
				
				faviconImg= $('.thumb img').attr('src');
				$('link[rel="shortcut icon"]').attr('href', $('.thumb img').attr('src'));
			} else {
				setTimeout(function() {
					initCount++;
					if (initCount < 50) {
						getURL();
					}

				}, 1000);
			}

		} else {
			faviconImg= imgSrc;
			//修改图标
			$('link[rel="shortcut icon"]').attr('href', imgSrc);
		}
	} catch (e) {
		setTimeout(function() {
			initCount++;
			if (initCount < 50) {
				getURL();
			}

		}, 1000);
	}
}

var currentUrl;
window.onload=function(){
	
	// 保存当前地址栏 URL
	currentUrl = window.location.href;
	var initCount = 0;
	getURL();
	//checkUrlChange();
	// 每隔一段时间调用检查地址栏变化的函数
	setInterval(checkUrlChange, 1000); // 每秒钟检查一次
}
var attemptCount = 0; // 尝试计数器

function observeTarget() {
	if (attemptCount >= 50) {
		//console.log('目标元素不存在，无法监听');
		return;
	}

	// 判断目标元素是否存在
	if ($('.thumb img')) {
		// 获取目标元素
		var targetImg = $('.thumb img');

		// 获取初始的 src 属性值
		var initialSrc = targetImg.attr('src');
		setIcon(initialSrc);
		// 创建 MutationObserver 实例
		var observer = new MutationObserver(function(mutationsList) {
			mutationsList.forEach(function(mutation) {
				if (mutation.attributeName === 'src') {
					// src 属性发生变化时触发的事件
					console.log('src 属性已变化:', initialSrc);
					setIcon(initialSrc);
				}
			});
		});

		// 配置观察选项
		var config = {
			attributes: true
		};

		// 开始观察目标元素
		observer.observe($('.thumb')[0], config);
	} else {
		// 目标元素不存在，计数器加1并继续尝试
		attemptCount++;
		setTimeout(observeTarget, 1000); // 间隔1秒后继续尝试
	}
}

//observeTarget(); // 开始尝试监听目标元素