// alert("background.js");



function getResourcesByFench(url, sender, sendResponse) {
	fetch(url).then((response) => {
		if (response.ok) {
			response.text().then(function(resolve) {
				
				var actionJson = {
					action: "ajaxResult",
					responseText: resolve
				}

				chrome.tabs.query({
					'url': [sender.url],
				}, function(tabs) {
					tabs.forEach(function(tab) {
					
						chrome.tabs.sendMessage(
							tab.id, actionJson,
							function(response) {
								// console.log(response);
							}
						);

					});
				});

				// sendMessageToPlayAfreecatv(actionJson);
			})
		}

	}, (error) => {
		console.log(error);
	});
}

// $.ajax({
// 	url: 'https://afubaba.github.io/Afreecatv/afreecatv.son.html',
// 	type: 'get',
// 	dataType: 'html',
// 	success: function(result, statis) {
// 		console.log(result);
// 		console.log(statis);
// 		// $("#broadlist_area").html(result);
// 	},
// 	error: function(error, errorMessage) {
// 		console.log(error);
// 		console.log(errorMessage);
// 	}
// });


var opt = {
	type: "image",
	title: "reload",
	message: "reload success",
	iconUrl: "https://afubaba.github.io/Afreecatv/logo/logo-128-2.png",
	imageUrl: "https://afubaba.github.io/Afreecatv/img/bg1.webp"
}
chrome.notifications.create("cakeNotification", opt);
//接收脚本消息
chrome.runtime.onMessage.addListener(
	function(request, sender, sendResponse) {

		if (request.action == "ajax") {
			getResourcesByFench(request.url, sender, sendResponse);
		}
		//接收内容脚本发送的消息
		if (request.action == "Hellow") {
			// alert("11");

			sendResponse({
				kw: "1"
			});
		}
		//接收拓展脚本发送的消息
		if (request.action == "Background") {
			// alert("11");
			sendResponse({
				kw: "Background"
			});
		}
		if (request.seAction == "searchBackData") {

			//indexdb
			opIndexDB.searchById(extensionId, "optiosDB", 1, "options", sender);
			//websql
			// opWebsql.seachData(extensionId);


			// sendMessageToPlayAfreecatv({
			// 	changeBackground: "changeBackground",
			// 	changeBackColor: "changeBackColor",
			// 	"color": data.fontColor,
			// 	"background": data.backColor
			// });


		}
	});

// chrome.runtime.onMessage.addListener(
//   function  (request, sender, sendResponse) {

//       alert(document.getElementById("testMatchs").innerHTML);

//       sendResponse({ response:"nihao"});

//   });


/* var i = 0;
setInterval(function() {
	i++;
	if (i == 60) {
		i = 0;
	}
	console.log(i);
}, 1000); */

// chrome.alarms.create('alarmsTest', {
// 	periodInMinutes: 0.25,
// 	/* delayInMinutes: 0, */
// });
// chrome.alarms.onAlarm.addListener(
// 	function(alarm) {	
// 		console.log(alarm);
// 	}
// );




//通用发消息到Play.afreecatv.js
async function sendMessageToPlayAfreecatv(actionName) {


	chrome.tabs.query({
		/* 'active': true, */
		'url': ["*://play.afreecatv.com/*"],
	}, function(tabs) {
		tabs.forEach(function(tab) {
			console.log(tab);
			// if (tab.status == "loading") {
			chrome.tabs.sendMessage(
				tab.id, actionName,
				function(response) {
					// console.log(response);
				}
			);
			// }
		});
	});
}
const extensionId = chrome.i18n.getMessage("@@extension_id");
var db;
var msg;
var opWebsql = {
	getDB: function() {
		db = openDatabase('optionsDB', '1.0', 'TestDB', 2 * 1024 * 1024, function(result) {
			db = result;
		});
		if (!db) {
			console.log("数据库创建失败！");
			return;
		} else {
			console.log("数据库创建成功！");
		}
	},
	seachData: function(tbName) {
		this.getDB();
		db.transaction(function(tx) {
			tx.executeSql('SELECT * FROM ' + tbName, [], function(tx, results) {

				// console.log(results.rowsAffected);

				var data = results.rows[0];

				console.log(data);
				// getDomById("background_color").value = data.fontColor;
				// getDomById("background").value = data.backColor;
			}, null);

		});

	}
}


var req;
var opIndexDB = {
	aa: function() {
		console.log("test");
	},
	getDB: function(dbName, version) {
		req = indexedDB.open(dbName, version);
		return req;
	},
	createTable: function(dbName, version, tbName) {
		req = this.getDB(dbName, version);
		req.onupgradeneeded = function(e) {
			console.error('onupgradeneeded');
			var db = req.result;
			// var store = db.createObjectStore("student", {autoIncrement: true}); 使用自增键
			// 创建student表
			var store = db.createObjectStore(tbName, {
				keyPath: 'id'
			});
			// 设置id为主键
			store.createIndex(tbName + '_id_unqiue', 'id', {
				unique: true
			});
		}
		return req;
	},
	insertData: function(dbName, version, tbName, options) {
		req = this.createTable(dbName, version, tbName);
		req.onsuccess = function(event) {
			console.log('onsuccess');
			// 获取数据库
			var db = event.target.result;
			// var transaction = db.transaction('option', 'readwrite');
			console.log(tbName);
			var transaction = db.transaction([tbName], 'readwrite');
			transaction.onsuccess = function(event) {
				console.log('[Transaction] 好了!');
			};
			transaction.onerror = function(event) {
				console.log('[Transaction] 失败!');
			};
			//读取表名
			var optionsStore = transaction.objectStore(tbName);
			options.forEach(function(option) {
				//数据储存
				console.log(option);
				var db_op_req = optionsStore.add(option);
				db_op_req.onsuccess = function() {
					console.log("存好了");
				}
			});
		}
		req.onerror = function() {
			console.log("数据库出错");
		}
	},
	searchById: function(id, dbName, version, tbName, sender) {
		req = this.createTable(dbName, version, tbName);
		req.onsuccess = function(events) {
			// 获取数据库
			var db = events.target.result;
			// var transaction = db.transaction('student', 'readwrite');
			var transaction = db.transaction([tbName], 'readwrite');
			transaction.onsuccess = function(event) {
				console.log('[Transaction] 好了!');
			};
			transaction.onerror = function(event) {
				console.log('[Transaction] 失败!');
			};

			//读取表名
			var optionsStore = transaction.objectStore(tbName);
			optionsStore.get(id).onsuccess = function(event) {
				// console.log("id为" + id + "的配置是", event.target.result);
				// seData(event.target.result);
				var data = event.target.result;
				// console.log(data);
				/* getDomById("background_color").value = data.fontColor;
				getDomById("background").value = data.backColor; */

				//改变正在显示的

				setTimeout(function() {
					// sendMessageToPlayAfreecatv({
					// 	action: "changeBackColor",
					// 	"color": data.fontColor
					// });
					// sendMessageToPlayAfreecatv({
					// 	action: "changeBackground",
					// 	"background": data.backColor
					// });
					let backData = {
						changeBackground: "changeBackground",
						changeBackColor: "changeBackColor",
						color: data.fontColor,
						background: data.backColor
					}
					chrome.tabs.query({
						'url': [sender.url],
					}, function(tabs) {
						tabs.forEach(function(tab) {
							console.log(tab);
							chrome.tabs.sendMessage(
								tab.id, backData,
								function(response) {
									// console.log(response);
								}
							);

						});
					});



					sendMessageToPlayAfreecatv();


				}, 4000);
				// sendMessageToPlayAfreecatv({
				// 	action: "changeBackColor",
				// 	"color": data.fontColor
				// });
				// sendMessageToPlayAfreecatv({
				// 	action: "changeBackground",
				// 	"background": data.backColor
				// });


				return data;
			};
		}
		req.onerror = function(events) {
			console.log("searchById查询出错了");
		}
	},
	updateData: function(option, dbName, version, tbName) {
		req = this.createTable(dbName, version, tbName);
		req.onsuccess = function(events) {

			// 获取数据库
			var db = events.target.result;
			// var transaction = db.transaction('student', 'readwrite');
			var transaction = db.transaction([tbName], 'readwrite');
			transaction.onsuccess = function(event) {
				console.log('[Transaction] 好了!');
			};
			transaction.onerror = function(event) {
				console.log('[Transaction] 失败!');
			};

			//读取表名
			var optionsStore = transaction.objectStore(tbName);
			console.log(optionsStore);
			optionsStore.put(option).onsuccess = function(event) {
				console.log('更新id为1的学生姓名', event.target.result);
			};
		}
		req.onerror = function(events) {
			console.log("updateData更新出错了");
		}
	}
}



//取消全部
chrome.contextMenus.removeAll(function() {
	console.log("移除所有");
});

// 右键菜单

const separator1 = {
	type: 'separator',
	id: 'separator1',
	visible: true,

}
//分割线
chrome.contextMenus.create(separator1);


const options = {
	documentUrlPatterns: ["*://*.afreecatv.com/*", "*://afreecatv.com/*"],
	type: 'normal',
	id: 'continuouClicker',
	title: 'demoMenu1',
	visible: true

}
chrome.contextMenus.create(options, () => {
	console.log("Created Success, id:${options.id}");
});

const separator2 = {
	type: 'separator',
	id: 'separator2',
	documentUrlPatterns: ["*://*.afreecatv.com/*", "*://afreecatv.com/*"],
	visible: true
}
//分割线
chrome.contextMenus.create(separator2);


const allClick = {
	type: 'normal',
	// parentId:"",
	// checked:true/false //单选框/复选框checkbox or radio
	enabled: false,
	documentUrlPatterns: ["*://*.afreecatv.com/*", "*://afreecatv.com/*"],
	//targetUrlPatterns //与 类似documentUrlPatterns，过滤器基于、和标签的src属性和标签的属性。imgaudiovideohrefa
	id: 'allClick',
	title: 'allClick',
	contexts: ['all'],
	visible: true,
	// onclick: genericOnClick
}
chrome.contextMenus.create(allClick, () => {
	console.log("Created Success, id:${allClick.id}");
});
const separator3 = {
	documentUrlPatterns: ["*://*.afreecatv.com/*", "*://afreecatv.com/*"],
	type: 'separator',
	id: 'separator3',
	visible: true

}
//分割线
chrome.contextMenus.create(separator3);

const page = {
	documentUrlPatterns: ["*://*.afreecatv.com/*", "*://afreecatv.com/*"],
	type: "normal",
	id: "page",
	title: "page",
	contexts: ["page"],
	visible: true
}
chrome.contextMenus.create(page);

const frame = {
	documentUrlPatterns: ["*://*.afreecatv.com/*", "*://afreecatv.com/*"],
	type: "normal",
	id: "frame",
	title: "frame",
	contexts: ["frame"],
	visible: true
}
chrome.contextMenus.create(frame);
const selection = {
	documentUrlPatterns: ["*://*.afreecatv.com/*", "*://afreecatv.com/*"],
	type: "normal",
	id: "selection",
	title: "selection",
	contexts: ["selection"],
	visible: true
}
chrome.contextMenus.create(selection);
const link = {
	documentUrlPatterns: ["*://*.afreecatv.com/*", "*://afreecatv.com/*"],
	type: "normal",
	id: "link",
	title: "link",
	contexts: ["link"],
	visible: true
}
chrome.contextMenus.create(link);
const editable = {
	documentUrlPatterns: ["*://*.afreecatv.com/*", "*://afreecatv.com/*"],
	type: "normal",
	id: "editable",
	title: "editable",
	contexts: ["editable"],
	visible: true
}
chrome.contextMenus.create(editable);
const image = {
	documentUrlPatterns: ["*://*.afreecatv.com/*", "*://afreecatv.com/*"],
	type: "normal",
	id: "image",
	title: "image",
	contexts: ["image"],
	visible: true
}
chrome.contextMenus.create(image);
const video = {
	documentUrlPatterns: ["*://*.afreecatv.com/*", "*://afreecatv.com/*"],
	type: "normal",
	id: "video",
	title: "video",
	contexts: ["video"],
	visible: true
}
chrome.contextMenus.create(video);
const audio = {
	documentUrlPatterns: ["*://*.afreecatv.com/*", "*://afreecatv.com/*"],
	type: "normal",
	id: "audio",
	title: "audio",
	contexts: ["audio"],
	visible: true
}
chrome.contextMenus.create(audio);
// const launcher={
// 	type:"normal",
// 	id:"launcher",
// 	title:"launcher",
// 	contexts:["launcher"],
// 	visible:true
// }
//
// chrome.contextMenus.create(launcher);
const browser_action = {
	documentUrlPatterns: ["*://*.afreecatv.com/*", "*://afreecatv.com/*"],
	type: "normal",
	id: "browser_action",
	title: "browser_action",
	contexts: ["browser_action"],
	visible: true
}
chrome.contextMenus.create(browser_action);
const page_action = {
	documentUrlPatterns: ["*://*.afreecatv.com/*", "*://afreecatv.com/*"],
	type: "normal",
	id: "page_action",
	title: "page_action",
	contexts: ["page_action"],
	visible: true
}
chrome.contextMenus.create(page_action);

// const action = {
// 	documentUrlPatterns: ["*://*.afreecatv.com/*", "*://afreecatv.com/*"],
// 	type: "normal",
// 	id: "action",
// 	title: "action",
// 	contexts: ["action"],
// 	visible: true
// }
// chrome.contextMenus.create(action);


// function genericOnClick(info, tab) {
// 	console.log(info);
// }
chrome.contextMenus.onClicked.addListener(
	function genericOnClick(info, tab) {
		console.log(info);

		if (info.menuItemId == "cn") {
			var url = 'http://translate.google.com.hk/#auto/zh-CN/' + info.selectionText;
			chrome.windows.create(url, '_blank');
		}
		if (info.menuItemId == "continuouClicker") {
			console.log(info)
		}

		if (info.menuItemId == 'saveall') {
			console.log('saveall');

			function text(results) {
				if (results && results[0] && results[0].length) {
					results[0].forEach(function(url) {
						chrome.downloads.download({
							url: url,
							conflictAction: 'uniquify',
							saveAs: false
						});
					});
				}
			}

			chrome.scripting.executeScript({
					target: {
						tabId: tab.id
					},
					files: ["js/main.js"]
				},
				/* (results) => {} */
				function(results) {

					if (results && results[0] && results[0].result.length) {
						console.log("可以");
						results[0].result.forEach(function(url) {
							chrome.downloads.download({
								url: url,
								conflictAction: 'uniquify',
								saveAs: false
							});
						});
					}
				}
			);

			/* chrome.downloads.download({
				url: "https://stimg.afreecatv.com/NORMAL_BBS/2/10729882/3308625080d3da64e.gif",
				conflictAction: 'uniquify',
				 filename :"nihao", 
				saveAs: false,
				method: "GET"
			}); */
		}

	}
);

chrome.contextMenus.create({
	type: 'normal',
	title: '使用Google翻译……',
	contexts: ['selection'],
	id: 'cn'
	// onclick: translate,
});


chrome.action.onClicked.addListener((tab) => {
	// chrome.scripting.executeScript({
	//   target: {tabId: tab.id},
	//   files: ['content.js']
	// });
	console.log(tab);
	console.log(tab.id);
	setIndexTab(tab);
	async function setIndexTab(tab) {

		chrome.browserAction.setTitle({
			tabId: tab.id,
			title: 'this is home'
		});
		// chrome.browserAction.setBadgeBackgroundColor({color: [0, 255,
		// 0, 128]});
		chrome.browserAction.setBadgeBackgroundColor({
			tabId: tab.id,
			color: 'red'
		});
		chrome.browserAction.setBadgeText({
			tabId: tab.id,
			text: 'home'
		});
		const ttPath = chrome.runtime.getURL("play.afreecatv.popup.html");
		chrome.browserAction.setPopup({
				popup: ttPath,
				tabId: tab.id
			},
			function() {
				console.log("qiehuan");
			}
		)

	}
});



chrome.runtime.onInstalled.addListener(function() {
	chrome.contextMenus.create({
		'id': 'saveall',
		'type': 'normal',
		'title': '保存所有图片',
	});
});
chrome.contextMenus.onClicked.addListener(function(info, tab) {
	if (info.menuItemId == 'saveall') {
		/* chrome.scripting.executeScript({
			file: 'main.js'
		}, function(results) {
			
		});
 */

		function text(results) {
			if (results && results[0] && results[0].length) {
				results[0].forEach(function(url) {
					chrome.downloads.download({
						url: url,
						conflictAction: 'uniquify',
						saveAs: false
					});
				});
			}
		}

		chrome.scripting.executeScript({
			target: {
				tabId: tab.id
			},
			files: ["js/main.js"],
			func: text()
		});
	}
});


chrome.storage.onChanged.addListener(function(changes, namespace) {
	for (let [key, {
			oldValue,
			newValue
		}] of Object.entries(changes)) {
		// console.log(
		// 	`储存键 "${key}" 在命名空间 "${namespace}" 改变了.`,
		// 	`老值是 "${oldValue}", 新值是 "${newValue}".`
		// );
		console.log(
			`储存键 "${key}" 在命名空间 "${namespace}" 改变了.\n老值是 "${oldValue}", 新值是 "${newValue}".`
		);
	}
});
