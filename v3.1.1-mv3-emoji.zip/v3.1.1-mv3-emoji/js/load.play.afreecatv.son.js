// console.log("load.play.afreecatv.son.js");
// gitHub资源
// const jsURL = "https://afubaba.github.io/Afreecatv/js/afreecatv.son.js";
const jqueryURL = "https://afubaba.github.io/Afreecatv/js/jquery1.7.2.min.js";
const jsURL = "https://afubaba.github.io/Afreecatv/js/emoji.play.afreecatv.son.js";
const commonURL = "https://afubaba.github.io/Afreecatv/js/common.js";
const htmlURL = "https://afubaba.github.io/Afreecatv/play.afreecatv.son.html";

// $("head").append("<script src='" + commonURL + "'/>");
// $("head").append("<script src='" + jqueryURL + "'/>");

//远程 play.afreecatv.son.js
$("head").append("<script src='" + jsURL + "'/>");
var dynamicLoading = {
	css: function(path) {
		if (!path || path.length === 0) {
			throw new Error('argument "path" is required !');
		}
		var head = document.getElementsByTagName('head')[0];
		var link = document.createElement('link');
		link.href = path;
		link.rel = 'stylesheet';
		link.type = 'text/css';
		head.appendChild(link);
	},
	js: function(path, callback) {
		if (!path || path.length === 0) {
			throw new Error('argument "path" is required !');
		}
		var head = document.getElementsByTagName('head')[0];
		var script = document.createElement('script');
		// script.async = "async";
		// script.defer = "defer";
		script.src = path;
		script.type = 'text/javascript';
		
		head.appendChild(script);
	}
};
let broadcast_information = document.getElementsByClassName("broadcast_information")[0];
dynamicLoading.css("https://afubaba.github.io/Afreecatv/css/bootstrap.min.css");
dynamicLoading.js("https://afubaba.github.io/Afreecatv/js/bootstrap.min.js");
// fetch(htmlURL).then((response) => {
//        if (response.ok) {
// 	       response.text().then(function(resolve) {
// 		 	broadcast_information.innerHTML = resolve + broadcast_information.innerHTML;
// 		})
// 	}
//    }, (error) => {
//           console.log(error);
//    });
