// console.log("index.js");
//背景图地址
var backUrl1 = "https://profile.img.afreecatv.com/LOGO/10/1057123999/1057123999.jpg";
var backUrl = "";

try{
	// backUrl = document.querySelector(".userInfo ").children[0].children[0].src;

}catch(e){
	//TODO handle the exception
	backUrl = "https://afubaba.github.io/Afreecatv/img/bg1.webp";
}
// backUrl = "https://stimg.afreecatv.com/NORMAL_BBS/9/18727399/575560df7f299c90c.jpg";
//清除背景.css('background-repeat','no-repeat')
$('*').css('background', 'none');
$('body').css('background', 'url(' + backUrl + ')').css('background-size', 'cover').css('height', '100%').css('width',
	'100%').css("backgroundRepeat", "no-repeat").css("backgroundPosition", "center");
